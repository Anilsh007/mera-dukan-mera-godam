create table if not exists public.subscriptions (
  id text primary key,
  user_id text not null unique,
  plan text not null,
  status text not null,
  trial_started_at timestamptz not null,
  trial_ends_at timestamptz not null,
  subscription_started_at timestamptz,
  subscription_ends_at timestamptz,
  provider text,
  provider_customer_id text,
  provider_subscription_id text,
  note text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.usage_tracking (
  id text primary key,
  user_id text not null,
  feature text not null,
  period_key text not null,
  count integer not null default 0,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (user_id, feature, period_key)
);

create index if not exists subscriptions_user_id_idx on public.subscriptions (user_id);
create index if not exists subscriptions_status_idx on public.subscriptions (status);
create index if not exists usage_tracking_user_feature_period_idx on public.usage_tracking (user_id, feature, period_key);
