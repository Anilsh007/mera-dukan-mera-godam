create table if not exists public.parties (
  id text primary key,
  user_id text not null,
  business_id text,
  name text not null,
  normalized_name text not null,
  mobile text,
  email text,
  gstin text,
  address text,
  city text,
  state text,
  pincode text,
  type text not null check (type in ('customer', 'supplier', 'both')),
  opening_balance numeric not null default 0,
  receivable numeric not null default 0,
  payable numeric not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists parties_user_normalized_name_idx
  on public.parties (user_id, normalized_name);

create table if not exists public.party_ledger (
  id text primary key,
  user_id text not null,
  business_id text,
  party_id text not null references public.parties(id) on delete cascade,
  type text not null check (type in ('payment-received', 'payment-paid', 'opening-balance')),
  amount numeric not null default 0,
  payment_mode text,
  note text,
  reference text,
  entry_date timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists party_ledger_user_party_idx
  on public.party_ledger (user_id, party_id, entry_date desc);
