import type { LocalizedSeoCopy } from "./types"

export const languageCode = "en"

export const enSeoCopy: LocalizedSeoCopy = {
  "softwareName": "Mera Dukan Mera Godam",
  "appDescription": "Inventory management, stock control, sales tracking, expiry alerts and GST billing software for Indian shops, retailers, wholesalers and small businesses.",
  "pages": {
    "/": {
      "title": "Inventory Management & GST Billing App for Shops in India",
      "description": "Use Mera Dukan Mera Godam to manage inventory, track stock, monitor sales, handle expiry alerts and create GST invoices for your shop or warehouse.",
      "keywords": [
        "free GST billing app",
        "inventory app for shops",
        "stock management app"
      ]
    },
    "/about": {
      "title": "About Mera Dukan Mera Godam",
      "description": "Learn how Mera Dukan Mera Godam helps Indian shops, warehouses and small businesses manage stock, GST billing, purchases, supplier dues and reports.",
      "keywords": [
        "about inventory software",
        "shop management mission"
      ]
    },
    "/faq": {
      "title": "Inventory & GST Billing App FAQ",
      "description": "Answers to common questions about inventory management, GST invoices, stock history, expiry alerts, supplier dues and business reports.",
      "keywords": [
        "GST billing FAQ",
        "inventory software questions"
      ]
    },
    "/privacy-policy": {
      "title": "Privacy Policy",
      "description": "Read the privacy policy for Mera Dukan Mera Godam and understand how business, inventory and account data is handled.",
      "keywords": [
        "privacy policy inventory app",
        "business data privacy"
      ]
    },
    "/support": {
      "title": "Support for Inventory, Stock & GST Billing",
      "description": "Get help with inventory setup, GST invoice generation, reports, supplier dues, stock history and business dashboard issues.",
      "keywords": [
        "inventory app support",
        "GST billing support"
      ]
    },
    "/terms": {
      "title": "Terms and Conditions",
      "description": "Review the terms and conditions for using Mera Dukan Mera Godam inventory, stock management and GST billing software.",
      "keywords": [
        "terms inventory app",
        "GST billing software terms"
      ]
    }
  }
}

export default enSeoCopy


export const exactUiText = {} as const

export const messageOverlay = {} as const
