import type { Metadata } from "next"
import Login from "@/app/components/auth/Login"
import JsonLd from "@/app/components/seo/JsonLd"
import { createPageMetadata, getSeoPage, resolveSeoLanguage, type SeoSearchParams } from "@/app/lib/seo/site"
import { createPageSchema } from "@/app/lib/seo/schema"

type PageProps = { searchParams?: SeoSearchParams }

export async function generateMetadata({ searchParams }: PageProps): Promise<Metadata> {
  const language = await resolveSeoLanguage(searchParams)
  return createPageMetadata(getSeoPage("/", language), language)
}

export default async function HomePage({ searchParams }: PageProps) {
  const language = await resolveSeoLanguage(searchParams)

  return (
    <main id="main-content">
      <JsonLd id="home-page-schema" data={createPageSchema("/", language)} />
      <Login />
    </main>
  )
}
