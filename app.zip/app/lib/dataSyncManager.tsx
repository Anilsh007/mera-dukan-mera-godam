"use client"

import { useEffect, useRef } from "react"
import { autoSyncToSupabase } from "./autoSupabaseSync.service"
import { syncSupabaseToDexie } from "./supabaseDownload.service"
import { auth } from "./firebase"
import { syncDexieToSupabase } from "./supabaseSync.service"
import { migrateLocalUserData } from "./userDataMigration"
import { notify } from "./notifications"
import { en } from "../messages/en"

export default function SupabaseSyncManager() {
  const hasShownSyncErrorRef = useRef(false)

  const showSyncError = () => {
    if (hasShownSyncErrorRef.current) return

    notify.error(en.notifications.syncError)
    hasShownSyncErrorRef.current = true
  }

  const resetSyncErrorGuard = () => {
    hasShownSyncErrorRef.current = false
  }

  useEffect(() => {
    if (!auth) return;

    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (!user) return

      try {
        await migrateLocalUserData(user)
        await syncDexieToSupabase()
        await syncSupabaseToDexie()
        resetSyncErrorGuard()
      } catch (err) {
        console.error("Initial Supabase sync failed:", err instanceof Error ? err.message : err)
        showSyncError()
      }
    })

    return () => unsubscribe()
  }, [])

  useEffect(() => {
    const runSync = () => {
      autoSyncToSupabase()
        .then(() => {
          return syncSupabaseToDexie()
        })
        .then(() => {
          resetSyncErrorGuard()
        })
        .catch((err) => {
          console.error("Supabase sync failed:", err instanceof Error ? err.message : err)
          showSyncError()
        })
    }

    if (typeof window === "undefined") return

    window.addEventListener("online", runSync)

    return () => {
      window.removeEventListener("online", runSync)
    }
  }, [])

  return null
}
