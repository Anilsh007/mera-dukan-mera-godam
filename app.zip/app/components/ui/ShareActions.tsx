"use client"

import type { ReactNode } from "react"
import { Copy, Download, Mail, Printer, Send, Share2 } from "lucide-react"
import { en } from "@/app/messages/en"
import { notify } from "@/app/lib/notifications"
import {
  buildShareDocument,
  getPdfFilename,
  copyTransactionDocument,
  downloadTransactionDocument,
  shareTransactionDocumentByEmail,
  shareTransactionDocumentNative,
  shareTransactionDocumentOnWhatsApp,
} from "@/app/lib/share"
import {
  buildMessageDocument,
  printTransactionDocument,
  type TransactionDocumentData,
} from "@/app/lib/transactionDocument"

type ShareActionsProps = {
  document?: TransactionDocumentData
  message?: string
  subject?: string
  filename?: string
  compact?: boolean
  className?: string
  showPrint?: boolean
  showDownload?: boolean
  showWhatsApp?: boolean
  showEmail?: boolean
  showNative?: boolean
  showCopy?: boolean
}

export default function ShareActions({
  document,
  message,
  subject,
  filename,
  compact = false,
  className = "",
  showPrint = true,
  showDownload = true,
  showWhatsApp = true,
  showEmail = true,
  showNative = true,
  showCopy = true,
}: ShareActionsProps) {
  const currentDocument = buildShareDocument({ document, message, subject })
  const disabled = !currentDocument
  const buttonClass = compact
    ? "inline-flex h-9 items-center justify-center gap-2 rounded-xl border border-[var(--border-card)] bg-[var(--surface-primary)] px-3 text-xs font-bold text-[var(--text-primary)] transition hover:border-[var(--accent)] hover:text-[var(--accent)] disabled:cursor-not-allowed disabled:opacity-60"
    : "inline-flex min-h-10 items-center justify-center gap-2 rounded-2xl border border-[var(--border-card)] bg-[var(--surface-primary)] px-4 py-2 text-sm font-bold text-[var(--text-primary)] transition hover:border-[var(--accent)] hover:text-[var(--accent)] disabled:cursor-not-allowed disabled:opacity-60"

  const getDocument = () => {
    if (currentDocument) return currentDocument
    if (message?.trim()) return buildMessageDocument({ message, subject })
    notify.warning(en.share.noDetailsToShare)
    return undefined
  }

  const handlePrint = () => {
    const nextDocument = getDocument()
    if (!nextDocument) return
    const printed = printTransactionDocument(nextDocument)
    if (printed) notify.success(en.print.printStarted)
    else notify.error(en.print.printFailed)
  }

  const handleDownload = () => {
    const nextDocument = getDocument()
    if (!nextDocument) return
    const downloaded = downloadTransactionDocument(nextDocument, getPdfFilename(filename, nextDocument))
    if (downloaded) notify.success(en.share.downloadStarted)
    else notify.error(en.share.downloadFailed)
  }

  const handleNativeShare = async () => {
    const nextDocument = getDocument()
    if (!nextDocument) return
    const result = await shareTransactionDocumentNative(nextDocument, getPdfFilename(filename, nextDocument))
    if (result === "shared") notify.info(en.share.shareOpened)
    else if (result === "downloaded") notify.success(en.share.downloadStarted)
    else notify.warning(en.share.nativeShareUnavailable)
  }

  const handleWhatsApp = async () => {
    const nextDocument = getDocument()
    if (!nextDocument) return
    const result = await shareTransactionDocumentOnWhatsApp(nextDocument, subject || nextDocument.title, getPdfFilename(filename, nextDocument))
    if (result === "failed") notify.error(en.share.shareFailed)
    else notify.info(en.share.shareOpened)
  }

  const handleEmail = async () => {
    const nextDocument = getDocument()
    if (!nextDocument) return
    const result = await shareTransactionDocumentByEmail(nextDocument, subject || nextDocument.title, getPdfFilename(filename, nextDocument))
    if (result === "failed") notify.error(en.share.shareFailed)
    else notify.info(en.share.shareOpened)
  }

  const handleCopy = async () => {
    const nextDocument = getDocument()
    if (!nextDocument) return
    const result = await copyTransactionDocument(nextDocument)
    if (result === "copied") notify.success(en.share.copiedSuccessfully)
    else notify.error(en.share.copyFailed)
  }

  return (
    <div className={`flex flex-wrap gap-2 ${className}`} aria-label={en.share.title}>
      {showPrint && <ActionButton className={buttonClass} disabled={disabled} icon={<Printer size={16} />} label={en.share.print} onClick={handlePrint} compact={compact} />}
      {showDownload && <ActionButton className={buttonClass} disabled={disabled} icon={<Download size={16} />} label={en.share.downloadPdf} onClick={handleDownload} compact={compact} />}
      {showNative && <ActionButton className={buttonClass} disabled={disabled} icon={<Share2 size={16} />} label={en.share.nativeShare} onClick={() => void handleNativeShare()} compact={compact} />}
      {showWhatsApp && <ActionButton className={buttonClass} disabled={disabled} icon={<Send size={16} />} label={en.share.whatsapp} onClick={() => void handleWhatsApp()} compact={compact} />}
      {showEmail && <ActionButton className={buttonClass} disabled={disabled} icon={<Mail size={16} />} label={en.share.email} onClick={() => void handleEmail()} compact={compact} />}
      {showCopy && <ActionButton className={buttonClass} disabled={disabled} icon={<Copy size={16} />} label={en.share.copyDetails} onClick={() => void handleCopy()} compact={compact} />}
    </div>
  )
}

function ActionButton({
  className,
  disabled,
  icon,
  label,
  onClick,
  compact,
}: {
  className: string
  disabled: boolean
  icon: ReactNode
  label: string
  onClick: () => void
  compact: boolean
}) {
  return (
    <button type="button" className={className} onClick={onClick} disabled={disabled} title={label}>
      <span aria-hidden="true">{icon}</span>
      <span className={compact ? "sr-only sm:not-sr-only" : ""}>{label}</span>
    </button>
  )
}
