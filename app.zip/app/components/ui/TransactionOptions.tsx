"use client"

import {
  Copy,
  Download,
  FileClock,
  FileText,
  Mail,
  MessageCircle,
  Printer,
  Save,
  type LucideIcon,
} from "lucide-react"
import { en } from "@/app/messages/en"
import type { TransactionOptionFlags } from "@/app/lib/transactionDocument"

type TransactionOptionsProps = {
  value: TransactionOptionFlags
  onChange: (next: TransactionOptionFlags) => void
  allowGstInvoice?: boolean
  allowPrint?: boolean
  allowDownloadPdf?: boolean
  allowShareWhatsApp?: boolean
  allowShareEmail?: boolean
  allowCopyDetails?: boolean
  allowSaveAsDraft?: boolean
  disabled?: boolean
  className?: string
}

type OptionConfig = {
  key: keyof TransactionOptionFlags
  label: string
  description: string
  icon: LucideIcon
}

export default function TransactionOptions({
  value,
  onChange,
  allowGstInvoice = false,
  allowPrint = true,
  allowDownloadPdf = true,
  allowShareWhatsApp = true,
  allowShareEmail = true,
  allowCopyDetails = true,
  allowSaveAsDraft = false,
  disabled = false,
  className = "",
}: TransactionOptionsProps) {
  const options: OptionConfig[] = [
    {
      key: "saveTransaction",
      label: en.transaction.saveTransaction,
      description: en.transaction.saveTransactionHelp,
      icon: Save,
    },
    ...(allowSaveAsDraft
      ? [
          {
            key: "saveAsDraft" as const,
            label: en.transaction.saveAsDraft,
            description: en.transaction.saveAsDraftHelp,
            icon: FileClock,
          },
        ]
      : []),
    ...(allowGstInvoice
      ? [
          {
            key: "generateGstInvoice" as const,
            label: en.transaction.generateGstInvoice,
            description: en.transaction.generateGstInvoiceHelp,
            icon: FileText,
          },
        ]
      : []),
    ...(allowPrint
      ? [
          {
            key: "printReceipt" as const,
            label: en.transaction.printReceipt,
            description: en.transaction.printReceiptHelp,
            icon: Printer,
          },
        ]
      : []),
    ...(allowDownloadPdf
      ? [
          {
            key: "downloadPdf" as const,
            label: en.transaction.downloadPdf,
            description: en.transaction.downloadPdfHelp,
            icon: Download,
          },
        ]
      : []),
    ...(allowShareWhatsApp
      ? [
          {
            key: "shareWhatsApp" as const,
            label: en.transaction.shareWhatsApp,
            description: en.transaction.shareWhatsAppHelp,
            icon: MessageCircle,
          },
        ]
      : []),
    ...(allowShareEmail
      ? [
          {
            key: "shareEmail" as const,
            label: en.transaction.shareEmail,
            description: en.transaction.shareEmailHelp,
            icon: Mail,
          },
        ]
      : []),
    ...(allowCopyDetails
      ? [
          {
            key: "copyDetails" as const,
            label: en.transaction.copyDetails,
            description: en.transaction.copyDetailsHelp,
            icon: Copy,
          },
        ]
      : []),
  ]

  const setFlag = (key: keyof TransactionOptionFlags, checked: boolean) => {
    onChange({ ...value, [key]: checked })
  }

  return (
    <section className={`premium-surface rounded-2xl p-3 sm:p-4 ${className}`}>
      <p className="text-sm font-bold text-[var(--text-primary)]">{en.transaction.optionsTitle}</p>
      <p className="mt-1 text-xs leading-5 text-[var(--text-secondary)]">{en.transaction.optionsDescription}</p>
      <div className="mt-3 grid grid-cols-1 gap-2 min-[520px]:grid-cols-2">
        {options.map((option) => (
          <OptionRow key={option.key} label={option.label} description={option.description} icon={option.icon} checked={Boolean(value[option.key])} disabled={disabled} onChange={(checked) => setFlag(option.key, checked)} />
        ))}
      </div>
    </section>
  )
}

function OptionRow({
  label,
  description,
  icon: Icon,
  checked,
  disabled,
  onChange,
}: {
  label: string
  description: string
  icon: LucideIcon
  checked: boolean
  disabled?: boolean
  onChange: (checked: boolean) => void
}) {
  return (
    <label className="flex min-h-12 cursor-pointer items-start gap-3 rounded-xl border border-[var(--border-card)] bg-[var(--bg-card-strong)] px-3 py-3 text-sm text-[var(--text-primary)] transition hover:-translate-y-0.5 hover:shadow-md active:translate-y-0 motion-reduce:hover:translate-y-0">
      <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent)]" aria-hidden="true">
        <Icon size={16} />
      </span>
      <span className="min-w-0 flex-1 leading-5">
        <span className="block font-semibold">{label}</span>
        <span className="mt-0.5 block text-xs text-[var(--text-secondary)]">{description}</span>
      </span>
      <input
        type="checkbox"
        checked={checked}
        disabled={disabled}
        onChange={(event) => onChange(event.target.checked)}
        className="mt-1 h-4 w-4 shrink-0 cursor-pointer disabled:cursor-not-allowed"
      />
    </label>
  )
}
