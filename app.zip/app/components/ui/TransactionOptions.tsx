"use client"

import type { ReactNode } from "react"
import { CheckCircle2, ClipboardList, Copy, Download, FileText, Mail, Printer, Save, Send } from "lucide-react"
import type { TransactionOptionFlags } from "@/app/lib/transactionDocument"
import { en } from "@/app/messages/en"

type TransactionOptionsProps = {
  value: TransactionOptionFlags
  onChange: (next: TransactionOptionFlags) => void
  allowGstInvoice?: boolean
  allowPrint?: boolean
  allowDownloadPdf?: boolean
  allowShareWhatsApp?: boolean
  allowShareEmail?: boolean
  allowCopyDetails?: boolean
  allowSaveAsDraft?: boolean
  disabled?: boolean
  className?: string
}

type OptionKey = keyof TransactionOptionFlags

type OptionItem = {
  key: OptionKey
  label: string
  description: string
  icon: ReactNode
  required?: boolean
  visible: boolean
}

export default function TransactionOptions({
  value,
  onChange,
  allowGstInvoice = false,
  allowPrint = true,
  allowDownloadPdf = true,
  allowShareWhatsApp = true,
  allowShareEmail = true,
  allowCopyDetails = true,
  allowSaveAsDraft = false,
  disabled = false,
  className = "",
}: TransactionOptionsProps) {
  const options: OptionItem[] = [
    {
      key: "saveTransaction",
      label: en.transaction.saveTransaction,
      description: en.transaction.saveTransactionHelp,
      icon: <Save size={16} aria-hidden="true" />,
      required: true,
      visible: true,
    },
    {
      key: "saveAsDraft",
      label: en.transaction.saveAsDraft,
      description: en.transaction.saveAsDraftHelp,
      icon: <ClipboardList size={16} aria-hidden="true" />,
      visible: allowSaveAsDraft,
    },
    {
      key: "generateGstInvoice",
      label: en.transaction.generateGstInvoice,
      description: en.transaction.generateGstInvoiceHelp,
      icon: <FileText size={16} aria-hidden="true" />,
      visible: allowGstInvoice,
    },
    {
      key: "printReceipt",
      label: en.transaction.printReceipt,
      description: en.transaction.printReceiptHelp,
      icon: <Printer size={16} aria-hidden="true" />,
      visible: allowPrint,
    },
    {
      key: "downloadPdf",
      label: en.transaction.downloadPdf,
      description: en.transaction.downloadPdfHelp,
      icon: <Download size={16} aria-hidden="true" />,
      visible: allowDownloadPdf,
    },
    {
      key: "shareWhatsApp",
      label: en.transaction.shareWhatsApp,
      description: en.transaction.shareWhatsAppHelp,
      icon: <Send size={16} aria-hidden="true" />,
      visible: allowShareWhatsApp,
    },
    {
      key: "shareEmail",
      label: en.transaction.shareEmail,
      description: en.transaction.shareEmailHelp,
      icon: <Mail size={16} aria-hidden="true" />,
      visible: allowShareEmail,
    },
    {
      key: "copyDetails",
      label: en.transaction.copyDetails,
      description: en.transaction.copyDetailsHelp,
      icon: <Copy size={16} aria-hidden="true" />,
      visible: allowCopyDetails,
    },
  ]

  const toggle = (key: OptionKey, checked: boolean) => {
    if (key === "saveTransaction") return
    onChange({ ...value, [key]: checked })
  }

  return (
    <fieldset className={`rounded-2xl border border-[var(--border-card)] bg-[var(--surface-primary)] p-3 ${className}`} disabled={disabled}>
      <legend className="px-1 text-sm font-bold text-[var(--text-primary)]">{en.transaction.optionsTitle}</legend>
      <p className="mb-3 px-1 text-xs leading-5 text-[var(--text-secondary)]">{en.transaction.optionsDescription}</p>
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {options.filter((option) => option.visible).map((option) => {
          const checked = Boolean(value[option.key]) || Boolean(option.required)
          return (
            <label
              key={option.key}
              className={`flex min-h-20 cursor-pointer gap-3 rounded-2xl border p-3 transition ${checked ? "border-[var(--accent)] bg-[var(--accent-soft)]" : "border-[var(--border-card)] bg-[var(--bg-card-strong)]"} ${disabled ? "cursor-not-allowed opacity-70" : "hover:border-[var(--accent)]"}`}
            >
              <input
                type="checkbox"
                checked={checked}
                onChange={(event) => toggle(option.key, event.target.checked)}
                disabled={disabled || option.required}
                className="mt-1 h-4 w-4 shrink-0 accent-[var(--accent)]"
              />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2 text-sm font-bold text-[var(--text-primary)]">
                  <span className="text-[var(--accent)]">{option.required ? <CheckCircle2 size={16} aria-hidden="true" /> : option.icon}</span>
                  {option.label}
                </span>
                <span className="mt-1 block text-xs leading-5 text-[var(--text-secondary)]">{option.description}</span>
              </span>
            </label>
          )
        })}
      </div>
    </fieldset>
  )
}
