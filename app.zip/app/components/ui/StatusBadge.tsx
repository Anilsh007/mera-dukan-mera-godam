import type { ReactNode } from "react"

type StatusBadgeTone = "success" | "warning" | "danger" | "neutral" | "info"

type StatusBadgeProps = {
  children: ReactNode
  tone?: StatusBadgeTone
  className?: string
}

const toneClass: Record<StatusBadgeTone, string> = {
  success: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
  warning: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  danger: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300",
  neutral: "bg-slate-100 text-slate-700 dark:bg-white/10 dark:text-slate-200",
  info: "bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300",
}

export default function StatusBadge({ children, tone = "neutral", className = "" }: StatusBadgeProps) {
  return <span className={`rounded-full px-3 py-1 text-xs font-semibold ${toneClass[tone]} ${className}`}>{children}</span>
}
