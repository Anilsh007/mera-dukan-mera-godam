"use client"

import { useRef, type ElementRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Float, MeshDistortMaterial, Sphere } from "@react-three/drei"

function AnimatedBackground() {
  const meshRef = useRef<ElementRef<typeof MeshDistortMaterial> | null>(null)

  useFrame((state) => {
    if (!meshRef.current) return
    const time = state.clock.getElapsedTime()
    const hue = Math.sin(time * 0.3) * 0.05 + 0.45
    meshRef.current.color.setHSL(hue, 0.7, 0.5)
  })

  return (
    <Float speed={2} rotationIntensity={2} floatIntensity={2}>
      <Sphere args={[1, 48, 48]} scale={2.5}>
        <MeshDistortMaterial ref={meshRef} distort={0.42} speed={1.6} roughness={0.18} metalness={0.15} />
      </Sphere>
    </Float>
  )
}

export default function LoginScene() {
  return (
    <Canvas camera={{ position: [0, 0, 5] }} dpr={[1, 1.5]} performance={{ min: 0.65 }}>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <AnimatedBackground />
    </Canvas>
  )
}
