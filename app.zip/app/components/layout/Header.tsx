"use client";

import { useState, useEffect, useRef } from "react";
import { signOut, onAuthStateChanged, User } from "firebase/auth";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { auth } from "@/app/lib/firebase";
import ThemeToggle from "@/app/components/theme/ThemeToggle";
import LanguageSelector from "@/app/components/layout/LanguageSelector";
import Link from "next/link";
import { LogOut, Menu, User as UserIcon } from "lucide-react";
import logo from "@/assets/logo.svg";
import { en } from "@/app/messages/en";

const accountMenuId = "account-menu";

export default function Header({ onMenuClick }: { onMenuClick?: () => void }) {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!auth) return;

    return onAuthStateChanged(auth, (currentUser) => setUser(currentUser));
  }, []);

  useEffect(() => {
    const close = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) setOpen(false);
    };

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };

    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, []);

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
    router.push("/");
  };

  return (
    <header className="fixed inset-x-0 top-0 z-40 flex min-h-16 min-w-0 items-center justify-between gap-2 border-b border-[var(--border-card)] bg-[color-mix(in_srgb,var(--bg-header)_88%,transparent)] px-3 py-2 shadow-[var(--shadow-header)] backdrop-blur-xl sm:gap-3 sm:px-4 lg:sticky lg:bg-[var(--bg-header)]">

      <div className="flex min-w-0 flex-1 items-center justify-start gap-2">
        {onMenuClick ? (
          <button
            type="button"
            onClick={onMenuClick}
            className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--bg-elevated)] text-[var(--text-primary)] transition-colors hover:border-[var(--accent)] hover:bg-[var(--accent-soft)] lg:hidden"
            aria-label={en.common.openMenu}
          >
            <Menu size={22} aria-hidden="true" />
          </button>
        ) : null}
        <div className="flex min-w-0 items-center justify-center lg:hidden">
          <Image src={logo} width={28} height={28} className="h-7 w-7 object-contain" alt={en.common.appName} priority />
          <div className="ml-2 hidden min-w-0 flex-col items-start sm:flex">
            <p className="truncate text-sm font-semibold text-[var(--text-primary)]">{en.common.appName}</p>
            <p className="hidden text-xs text-[var(--text-muted)] md:block">{en.navigation.workspaceTagline}</p>
          </div>
        </div>
      </div>

      <div className="flex shrink-0 items-center justify-end gap-1.5 sm:gap-2.5">
        <LanguageSelector />
        <ThemeToggle />

        <div className="relative" ref={ref}>
          <button
            type="button"
            onClick={() => setOpen((current) => !current)}
            className="cursor-pointer flex max-w-[44px] items-center gap-2 rounded-[22px] border border-[var(--border-card)] bg-[var(--bg-header)] py-1 pl-1 pr-1 shadow-[var(--shadow-header)] backdrop-blur-xl transition-all hover:-translate-y-0.5 hover:border-[var(--accent)] sm:max-w-[220px] sm:pr-3"
            aria-haspopup="menu"
            aria-expanded={open}
            aria-controls={open ? accountMenuId : undefined}
            aria-label={en.common.profile}
          >
            {user?.photoURL ? (
              <Image src={user.photoURL} unoptimized referrerPolicy="no-referrer" alt={en.common.profileAlt} width={32} height={32} className="h-8 w-8 rounded-2xl object-cover" />
            ) : (
              <div className="flex h-8 w-8 items-center justify-center rounded-2xl bg-[var(--accent-soft)]" aria-hidden="true">
                <UserIcon size={14} className="text-emerald-600" />
              </div>
            )}

            <div className="hidden min-w-0 sm:block">
              <p className="max-w-[110px] truncate text-xs font-semibold text-[var(--text-primary)]">
                {user?.displayName?.split(" ")[0] || en.common.user}
              </p>
            </div>
          </button>

          {open && (
            <div id={accountMenuId} className="absolute right-0 z-50 mt-2 w-[min(18rem,calc(100vw-1.5rem))] overflow-hidden rounded-2xl border border-[var(--border-card)] bg-[var(--bg-card-strong)] shadow-[var(--shadow-card)] backdrop-blur-xl" role="menu">
              <div className="border-b border-[var(--border-color)] px-4 py-3">
                <p className="text-xs text-[var(--text-muted)]">{en.navigation.signedInAs}</p>
                <p className="truncate text-sm font-semibold text-[var(--text-primary)]">{user?.displayName || user?.email}</p>
                {user?.displayName && <p className="truncate text-xs text-[var(--text-muted)]">{user?.email}</p>}
              </div>

              <Link href="/dashboard/profile" role="menuitem" className="w-full flex items-center gap-3 px-4 py-3 text-sm text-[var(--text-primary)] transition-colors hover:bg-[var(--bg-soft)]" onClick={() => setOpen(false)}>
                <UserIcon size={15} aria-hidden="true" /> {en.common.profile}
              </Link>
              <button type="button" role="menuitem" onClick={handleLogout} className="w-full cursor-pointer flex items-center gap-3 px-4 py-3 text-sm text-red-500 transition-colors hover:bg-red-500/10">
                <LogOut size={15} aria-hidden="true" /> {en.common.logout}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
