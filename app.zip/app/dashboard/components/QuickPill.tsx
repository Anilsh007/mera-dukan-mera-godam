"use client"

import type { ReactNode } from "react"

type QuickPillProps = {
  icon: ReactNode
  label: string
  value: string
}

export default function QuickPill({ icon, label, value }: QuickPillProps) {
  return (
    <div className="rounded-2xl border border-[var(--border-card)] bg-[var(--bg-elevated)] px-4 py-3 shadow-[var(--shadow-card)]">
      <div className="flex items-center gap-2 text-[var(--text-secondary)]">
        {icon}
        <span className="text-[11px] font-medium uppercase tracking-wide">{label}</span>
      </div>
      <p className="mt-2 text-base font-bold text-[var(--text-primary)] sm:text-lg">{value}</p>
    </div>
  )
}
