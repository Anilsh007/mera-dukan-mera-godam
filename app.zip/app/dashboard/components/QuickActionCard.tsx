"use client"

import type { ReactNode } from "react"

type QuickActionCardProps = {
  title: string
  description: string
  icon: ReactNode
  accentClass?: string
  onClick: () => void
}

export default function QuickActionCard({
  title,
  description,
  icon,
  accentClass = "bg-emerald-500",
  onClick,
}: QuickActionCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group rounded-[24px] border border-[var(--border-card)] bg-[var(--bg-card-strong)] p-5 text-left shadow-[var(--shadow-card)] backdrop-blur-xl transition-all duration-200 hover:-translate-y-1 hover:border-[var(--accent)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--accent)]"
    >
      <div className={`mb-4 flex h-11 w-11 items-center justify-center rounded-2xl ${accentClass} text-white shadow-lg`}>
        {icon}
      </div>
      <p className="font-semibold text-[var(--text-primary)]">{title}</p>
      <p className="mt-1 text-xs leading-5 text-[var(--text-secondary)]">{description}</p>
    </button>
  )
}
