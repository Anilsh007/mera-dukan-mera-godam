"use client"

import { useEffect, useMemo, useState } from "react"

import InvoiceHeader from "./components/InvoiceHeader"
import SellerSection from "./components/SellerSection"
import BuyerSection, { matchProductSuggestion } from "./components/BuyerSection"
import ItemsSection from "./components/ItemsSection"
import BankNotesSection from "./components/BankNotesSection"
import InvoiceHistory from "./components/InvoiceHistory"
import InvoicePreview from "./Preview/InvoicePreview"

import useProfile from "@/app/dashboard/profile/useProfile"
import useProducts from "@/app/dashboard/all-stock/useProducts"
import { toast } from "sonner"

import {
  buildSellerFromProfile,
  buildBankDetailsFromProfile,
  buildInvoiceNumber,
  loadInvoicesFromDb,
  saveInvoiceToDb,
} from "./invoice.service"

import { buildBuyerSuggestions } from "./buyerSuggestions"

import {
  calculateGST,
  createEmptyInvoice,
  createEmptyInvoiceItem,
  type GSTInvoice,
  type GSTInvoiceItem,
  type GSTInvoiceRecord,
} from "./types/gst.types"

import { getStateFromGSTIN } from "./lib/getStateFromGSTIN"
import { syncSupabaseToDexie } from "@/app/lib/supabaseDownload.service"

const today = new Date().toISOString().slice(0, 10)

export default function GstForm() {
  const [invoice, setInvoice] = useState<GSTInvoice>(createEmptyInvoice())
  const [invoices, setInvoices] = useState<GSTInvoiceRecord[]>([])
  const [saving, setSaving] = useState(false)

  const { profile } = useProfile()
  const { products } = useProducts()

  // 🔥 INTER / INTRA STATE
  const isInterState =
    invoice.seller.state?.trim().toLowerCase() !==
    invoice.buyer.state?.trim().toLowerCase()

  // -----------------------------
  // PRODUCT SUGGESTIONS
  // -----------------------------
  const productSuggestions = useMemo(
    () =>
      products.map((p) => ({
        name: p.name,
        displayName: p.name,
        rate: p.price,
        hsnCode: p.sku || "",
        category: p.category || "",
      })),
    [products]
  )

  // -----------------------------
  // BUYER SUGGESTIONS
  // -----------------------------
  const buyerSuggestions = useMemo(
    () => buildBuyerSuggestions(invoices),
    [invoices]
  )

  // -----------------------------
  // INITIAL LOAD
  // -----------------------------
  useEffect(() => {
    async function init() {
      const data = await loadInvoicesFromDb()
      setInvoices(data)

      setInvoice((prev) => ({
        ...prev,
        invoiceNo: buildInvoiceNumber(profile, data),
        invoiceDate: today,
        dueDate: today,
        seller: buildSellerFromProfile(profile),
        bankDetails: buildBankDetailsFromProfile(profile),
      }))
    }

    if (profile) init()
  }, [profile])

  // -----------------------------
  // BUYER CHANGE
  // -----------------------------
  const handleBuyerChange = (field: string, value: string) => {
    let updatedBuyer = { ...invoice.buyer, [field]: value }

    if (field === "gstin") {
      const state = getStateFromGSTIN(value)
      if (state) updatedBuyer.state = state
    }

    setInvoice((prev) => ({
      ...prev,
      buyer: updatedBuyer,
    }))
  }

  // -----------------------------
  // ITEM CHANGE (🔥 MAIN FIX)
  // -----------------------------
  const handleItemChange = (
    index: number,
    field: keyof GSTInvoiceItem,
    value: string
  ) => {
    const items = [...invoice.items]

    // number fields
    if (field === "quantity" || field === "rate" || field === "gstRate") {
      items[index][field] = Number(value) as never
    } else {
      items[index][field] = value as never
    }

    // 🔥 AUTO FILL LOGIC
    if (field === "description") {
      const matched = matchProductSuggestion(productSuggestions, value)

      if (matched) {
        items[index].rate = matched.rate
        items[index].hsnCode = matched.hsnCode
        // 👉 agar tumhare GSTItem me category hai to:
        // items[index].category = matched.category
      }
    }

    setInvoice((prev) => ({
      ...prev,
      items,
    }))
  }

  // -----------------------------
  // 🔥 STATE CHANGE RE-CALCULATION
  // -----------------------------
  useEffect(() => {
    setInvoice((prev) => {
      const updatedItems = prev.items.map((item) => {
        const result = calculateGST(
          item.gstRate,
          item.quantity,
          item.rate,
          item.discount,
          isInterState
        )

        return {
          ...item,
          taxableValue: result.taxableValue,
          cgstAmount: result.cgst,
          sgstAmount: result.sgst,
          igstAmount: result.igst,
          total: result.total,
        }
      })

      return { ...prev, items: updatedItems }
    })
  }, [invoice.buyer.state, invoice.seller.state])

  // -----------------------------
  // ADD / REMOVE
  // -----------------------------
  const addItem = () => {
    setInvoice((prev) => ({
      ...prev,
      items: [...prev.items, createEmptyInvoiceItem()],
    }))
  }

  const removeItem = (index: number) => {
    setInvoice((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }))
  }

  // -----------------------------
  // RESET
  // -----------------------------
  const resetInvoice = () => {
    setInvoice({
      ...createEmptyInvoice(),
      invoiceNo: buildInvoiceNumber(profile, invoices),
      invoiceDate: today,
      dueDate: today,
      seller: buildSellerFromProfile(profile),
      bankDetails: buildBankDetailsFromProfile(profile),
    })
  }

  // -----------------------------
  // SAVE
  // -----------------------------
  const saveInvoice = async () => {
    const missing = [
      !invoice.seller.name && "seller name",
      !invoice.seller.gstin && "GSTIN",
      !invoice.seller.state && "state",
    ].filter(Boolean)

    if (missing.length) {
      toast.error(`Complete seller profile: ${missing.join(", ")}`)
      return
    }

    setSaving(true)
    try {
      const saved = await saveInvoiceToDb(invoice)
      setInvoices((prev) => [saved, ...prev])
      resetInvoice()
    } catch (err) {
      console.error(err)
    } finally {
      setSaving(false)
    }
  }

  // -----------------------------
  // LOAD HISTORY
  // -----------------------------
  const loadInvoiceFromHistory = (inv: GSTInvoiceRecord) => {
    setInvoice(inv)
  }

  useEffect(() => {
    async function syncData() {
      try {
        await syncSupabaseToDexie()
      } catch (err) {
        console.error("Manual sync failed:", err)
      }
    }

    syncData()
  }, [])

  // -----------------------------
  // UI
  // -----------------------------
  return (
    <div>
      <div className="space-y-6">
        <InvoiceHeader invoice={invoice} onChange={(f, v) => setInvoice({ ...invoice, [f]: v })} onSave={saveInvoice} onReset={resetInvoice} saving={saving} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SellerSection seller={invoice.seller} />
          <BankNotesSection invoice={invoice} onChange={(f, v) => setInvoice({ ...invoice, [f]: v })} />
        </div>

        <div className="p-6 bg-[var(--bg-card-strong)] rounded-2xl">
          <BuyerSection buyer={invoice.buyer} onChange={handleBuyerChange} suggestions={buyerSuggestions} />

          <ItemsSection items={invoice.items} onChange={handleItemChange} addItem={addItem} removeItem={removeItem} productSuggestions={productSuggestions} isInterState={isInterState} />
        </div>
      </div>

      <div className="space-y-6 sticky top-4">
        <InvoicePreview invoice={invoice} />
        <InvoiceHistory invoices={invoices} onSelect={loadInvoiceFromHistory} />
      </div>
    </div>
  )
}