"use client"

import GstForm from "./gstForm"
import InvoiceCopySelector from "./components/InvoiceCopySelector"
import { buildGstInvoiceCopyDocuments, type GstInvoiceCopyMode } from "./lib/invoiceCopy"

export default function GstInvoicePage() {
    return (
        <>
            <GstForm />
        </>
    )
}
