import Input from "@/app/components/utility/CommonInput";
import type { BuyerSectionProps } from "../types/ui.types";

export function matchProductSuggestion(
  suggestions: any[],
  value: string
) {
  const val = value.trim().toLowerCase()
  if (!val) return null

  return (
    suggestions.find(
      (p) => p.name.toLowerCase() === val
    ) || null
  )
}

export default function BuyerSection({ buyer, onChange, suggestions, }: BuyerSectionProps) {

  const buyerForm = [
    { label: "Buyer Name/Business Name", value: buyer.name, onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("name", e.target.value), datalist: "buyer-name" },
    { label: "GSTIN", value: buyer.gstin || "", onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("gstin", e.target.value) },
    { label: "State", value: buyer.state || "", onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("state", e.target.value) },
    { label: "Billing Address", value: buyer.address || "", onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("address", e.target.value) },
    { label: "Phone", value: buyer.phone || "", onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("phone", e.target.value) },
    { label: "Email", value: buyer.email || "", onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("email", e.target.value) },
    { label: "Pin Code", value: buyer.pincode || "", onChange: (e: React.ChangeEvent<HTMLInputElement>) => onChange("pincode", e.target.value) },
  ]
  return (
    <section>
      <h3>Buyer Details</h3>

      <datalist id="buyer-name">
        {suggestions.map((s) => (
          <option key={s.key} value={s.buyer.name} />
        ))}
      </datalist>

      <div className="grid md:grid-cols-4 gap-3 mt-4">
        {buyerForm.map((input, index) => (
          <Input
            key={index}
            label={input.label}
            value={input.value}
            onChange={input.onChange}
            datalist={input.datalist}
          />
        ))}
      </div>
    </section>
  );
}
