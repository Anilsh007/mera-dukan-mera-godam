import Input from "@/app/components/utility/CommonInput"
import Button from "@/app/components/utility/Button"
import { MdDeleteOutline } from "react-icons/md"
import { ItemCardProps } from "../types/ui.types"
import { FaEquals, FaPlus } from "react-icons/fa";

export default function ItemCard({ item, index, onChange, onRemove, isInterState, }: ItemCardProps) {

  return (
    <div className="border p-4 rounded-xl">
      <div className="flex justify-between">
        <p>Item {index + 1}</p>
        <Button variant="delete" icon={<MdDeleteOutline />} onClick={() => onRemove(index)} />
      </div>

      <div className="grid md:grid-cols-4 gap-2 mt-3">
        <Input label="Product" value={item.description} onChange={(e) => onChange(index, "description", e.target.value)} />
        <Input label="Category" value={item.category} datalist="products" onChange={(e) => onChange(index, "category", e.target.value)} />
        <Input label="HSN / SAC" value={item.hsnCode} onChange={(e) => onChange(index, "hsnCode", e.target.value)} />
        <Input label="Rate" type="number" value={String(item.rate)} onChange={(e) => onChange(index, "rate", e.target.value)} />
        <Input label="Qty" type="number" value={String(item.quantity)} onChange={(e) => onChange(index, "quantity", e.target.value)} />
        <Input label="Discount (₹)" type="number" value={String(item.discount)} onChange={(e) => onChange(index, "discount", e.target.value)} />
        <Input label="Expiry Date" type="date" value={String(item.expiry)} onChange={(e) => onChange(index, "expiry", e.target.value)} />
      </div>

      <div className="mt-4 space-y-4">

        {/* 🔹 Tax Type Badge */}
        <div className="text-xs font-medium">
          {isInterState ? (
            <span className="px-2 py-1 rounded-full bg-purple-100 text-purple-700">
              Inter-state • IGST applied
            </span>
          ) : (
            <span className="px-2 py-1 rounded-full bg-emerald-100 text-emerald-700">
              Intra-state • CGST + SGST
            </span>
          )}
        </div>

        {/* 🔥 MAIN TAX ROW */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3 rounded-xl bg-[var(--bg-input)] border p-3">

          {/* LEFT: Taxable */}
          <div className="flex-1 text-center md:text-left">
            <p className="text-xs text-gray-400">Taxable</p>
            <p className="text-lg font-semibold">
              ₹ {item.taxableValue.toFixed(2)}
            </p>
          </div>

          {/* PLUS */}
          <FaPlus size={20} />

          {/* TAX SECTION */}
          <div className="flex flex-1 items-center justify-center gap-4">

            {isInterState ? (
              <div className="text-center">
                <p className="text-xs text-purple-400">IGST</p>
                <p className="text-lg font-semibold text-purple-500">
                  ₹ {item.igstAmount.toFixed(2)}
                </p>
              </div>
            ) : (
              <>
                <div className="text-center">
                  <p className="text-xs text-emerald-400">CGST</p>
                  <p className="text-lg font-semibold text-emerald-500">
                    ₹ {item.cgstAmount.toFixed(2)}
                  </p>
                </div>

                <FaPlus size={20} />

                <div className="text-center">
                  <p className="text-xs text-blue-400">SGST</p>
                  <p className="text-lg font-semibold text-blue-500">
                    ₹ {item.sgstAmount.toFixed(2)}
                  </p>
                </div>
              </>
            )}
          </div>

          <FaEquals size={20} />

          {/* RIGHT: TOTAL */}
          <div className="flex-1 text-center md:text-right">
            <p className="text-xs text-gray-400">Total</p>
            <p className="text-xl font-bold text-[var(--text-primary)]">
              ₹ {item.total.toFixed(2)}
            </p>
          </div>

        </div>
      </div>
    </div>
  )
}