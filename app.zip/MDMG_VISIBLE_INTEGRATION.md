# MDMG Visible Integration Fix

This ZIP includes all previous Phase 1-7 work plus the final visibility bridge for:

1. Overview dashboard charts
2. GST invoice customer/business/draft copy selector

Why this extra step exists:
- The previously uploaded ZIPs were partial patch bundles.
- The full real repo has `app/dashboard/page.tsx` and `app/dashboard/gst-invoice/page.tsx`, but those files were not present in the patch bundle.
- To avoid overwriting your real pages blindly, this ZIP includes an idempotent patch script.

## Apply steps

1. Extract/replace the ZIP files into your real project.
2. From the real project root, run:

```bash
node scripts/apply-visible-integrations.mjs
npm run typecheck
npm run lint
npm run build
```

The script safely attempts to:
- Add `<DashboardOverviewAutoCharts />` to `app/dashboard/page.tsx`.
- Add `<InvoiceCopySelector />` to `app/dashboard/gst-invoice/page.tsx`.
- Connect GST invoice copy mode to the newer `useGstInvoiceForm()` hook when present.
- Patch older inline GST invoice save/print/share action code when the page has not been refactored to the hook yet.

If the script prints a `[WARN]`, open the mentioned file and add the indicated component manually at that location.
