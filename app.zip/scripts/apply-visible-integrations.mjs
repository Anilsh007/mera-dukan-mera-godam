import fs from "node:fs"
import path from "node:path"

const root = process.cwd()
const dashboardPage = path.join(root, "app", "dashboard", "page.tsx")
const gstInvoicePage = path.join(root, "app", "dashboard", "gst-invoice", "page.tsx")

let changed = false

function readFile(filePath) {
  return fs.existsSync(filePath) ? fs.readFileSync(filePath, "utf8") : null
}

function writeFile(filePath, content) {
  fs.writeFileSync(filePath, content)
  changed = true
  console.log(`[OK] updated ${path.relative(root, filePath)}`)
}

function ensureImport(content, importLine) {
  if (content.includes(importLine)) return content
  const importMatches = [...content.matchAll(/^import .*$/gm)]
  if (!importMatches.length) return `${importLine}\n${content}`
  const lastImport = importMatches[importMatches.length - 1]
  const insertAt = lastImport.index + lastImport[0].length
  return `${content.slice(0, insertAt)}\n${importLine}${content.slice(insertAt)}`
}

function patchDashboardPage() {
  const original = readFile(dashboardPage)
  if (!original) {
    console.warn("[SKIP] app/dashboard/page.tsx was not found. Add <DashboardOverviewAutoCharts /> manually on the dashboard page.")
    return
  }

  let content = original
  content = ensureImport(content, 'import DashboardOverviewAutoCharts from "./components/DashboardOverviewAutoCharts"')

  if (!content.includes("<DashboardOverviewAutoCharts")) {
    const headerIndex = content.indexOf("</header>")
    if (headerIndex >= 0) {
      const insertAt = headerIndex + "</header>".length
      content = `${content.slice(0, insertAt)}\n\n      <DashboardOverviewAutoCharts />${content.slice(insertAt)}`
    } else {
      content = content.replace(/(<div[^>]*className=["'][^"']*dashboard-page[^"']*["'][^>]*>)/, "$1\n      <DashboardOverviewAutoCharts />")
    }
  }

  if (content !== original) writeFile(dashboardPage, content)
  else console.log("[OK] dashboard charts were already connected")
}

function patchGstInvoicePage() {
  const original = readFile(gstInvoicePage)
  if (!original) {
    console.warn("[SKIP] app/dashboard/gst-invoice/page.tsx was not found. Add <InvoiceCopySelector /> manually in the GST invoice form.")
    return
  }

  let content = original
  content = ensureImport(content, 'import InvoiceCopySelector from "./components/InvoiceCopySelector"')

  if (content.includes("useGstInvoiceForm()")) {
    content = addHookDestructure(content, "invoiceCopyMode")
    content = addHookDestructure(content, "setInvoiceCopyMode")
  } else {
    content = ensureImport(content, 'import { buildGstInvoiceCopyDocuments, type GstInvoiceCopyMode } from "./lib/invoiceCopy"')
    content = addLocalCopyModeState(content)
    content = patchLegacyInvoiceActions(content)
  }

  content = insertInvoiceCopySelector(content)

  if (content !== original) writeFile(gstInvoicePage, content)
  else console.log("[OK] GST invoice copy selector was already connected")
}

function addHookDestructure(content, key) {
  if (content.includes(key)) return content
  return content.replace(/const\s*\{([\s\S]*?)\}\s*=\s*useGstInvoiceForm\(\)/m, (match, body) => {
    const trimmedBody = String(body).trim()
    const needsComma = trimmedBody.length > 0 && !trimmedBody.endsWith(",")
    const separator = needsComma ? "," : ""
    return `const {${body}${separator}\n  ${key},\n} = useGstInvoiceForm()`
  })
}

function addLocalCopyModeState(content) {
  if (content.includes("invoiceCopyMode")) return content
  const stateLine = '  const [invoiceCopyMode, setInvoiceCopyMode] = useState<GstInvoiceCopyMode>("customer")'
  const transactionOptionsEnd = content.indexOf("  })", content.indexOf("const [transactionOptions"))
  if (transactionOptionsEnd >= 0) {
    const insertAt = transactionOptionsEnd + "  })".length
    return `${content.slice(0, insertAt)}\n${stateLine}${content.slice(insertAt)}`
  }
  return content.replace(/(const \[saving, setSaving\][^\n]*\n)/, `$1${stateLine}\n`)
}

function patchLegacyInvoiceActions(content) {
  if (content.includes("buildGstInvoiceCopyDocuments(buildGstInvoiceDocument(invoiceToSave), invoiceCopyMode)")) return content

  const oldBlock = `      if (transactionOptions.printReceipt) {
        const printed = printTransactionDocument(buildGstInvoiceDocument(invoiceToSave))
        if (printed) toast.success(en.common.printStarted)
        else toast.error(en.common.popupBlocked)
      }
      if (transactionOptions.downloadShare) {
        await shareTransactionDocument(buildGstInvoiceDocument(invoiceToSave))
      }`

  const newBlock = `      const invoiceDocuments = buildGstInvoiceCopyDocuments(buildGstInvoiceDocument(invoiceToSave), invoiceCopyMode)
      for (const invoiceDocument of invoiceDocuments) {
        if (transactionOptions.printReceipt) {
          const printed = printTransactionDocument(invoiceDocument)
          if (printed) toast.success(en.common.printStarted)
          else toast.error(en.common.popupBlocked)
        }
        if (transactionOptions.downloadShare) {
          await shareTransactionDocument(invoiceDocument)
        }
      }`

  return content.replace(oldBlock, newBlock)
}

function insertInvoiceCopySelector(content) {
  if (content.includes("<InvoiceCopySelector")) return content

  const transactionOptionsMatch = content.match(/<TransactionOptions[\s\S]*?\/>/)
  if (!transactionOptionsMatch || transactionOptionsMatch.index === undefined) {
    console.warn("[WARN] Could not find <TransactionOptions /> in GST invoice page. Add <InvoiceCopySelector /> manually near the invoice action options.")
    return content
  }

  const insertAt = transactionOptionsMatch.index + transactionOptionsMatch[0].length
  const selector = `
            <InvoiceCopySelector
              value={invoiceCopyMode}
              onChange={setInvoiceCopyMode}
              disabled={saving}
            />
`
  return `${content.slice(0, insertAt)}${selector}${content.slice(insertAt)}`
}

patchDashboardPage()
patchGstInvoicePage()

if (!changed) console.log("[OK] No changes needed")
console.log("Done. Now run: npm run typecheck && npm run lint && npm run build")
