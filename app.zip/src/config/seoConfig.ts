export const dugamSEOData = {
  brandName: "Dugam (Mera Dukan Mera Godam)",
  siteUrl: "https://www.dugam.in",
  pricing: {
    monthly: "₹99/month",
    yearly: "₹999/year",
    daily: "₹2.74/day",
    yearlyHook: "Sirf ₹2.74/din me poori dukan aur godam manage karein",
  },
  appDescription:
    "Dugam is an affordable inventory management and GST billing app for Indian MSMEs, kirana stores, wholesalers, retailers, and small business teams.",
  primaryKeywords: [
    "inventory management software",
    "stock management software",
    "inventory software india",
    "warehouse management software",
    "godown management software",
    "shop management software",
    "retail management software",
    "GST billing software",
    "GST invoice software",
    "GST bill generator",
    "GST bill maker",
    "billing software india",
    "retail billing software",
    "invoice software india",
    "stock inventory tracker",
    "inventory tracker app",
    "purchase management software",
    "sales management software",
    "expense management software",
    "POS software india",
    "retail POS software",
    "inventory management app",
    "stock management app",
    "free inventory software",
    "free GST billing software",
  ],
  businessKeywords: [
    "kirana store software",
    "grocery shop billing software",
    "hardware shop billing software",
    "electronics shop billing software",
    "mobile shop inventory software",
    "medical store inventory software",
    "pharmacy billing software",
    "garment shop billing software",
    "footwear shop inventory software",
    "stationery shop billing software",
    "wholesale inventory software",
    "distributor inventory software",
    "supermarket inventory software",
  ],
  pricingKeywords: [
    "billing software under 1000 rupees",
    "inventory software under 999 rupees",
    "affordable GST billing software",
    "budget inventory management software",
    "billing software for small business",
    "inventory software for MSME",
    "billing software under 100 rupees per month",
    "GST software for small shops",
  ],
  competitorKeywords: [
    "Vyapar alternative",
    "TallyPrime alternative",
    "myBillBook alternative",
    "Swipe alternative",
    "Busy Accounting alternative",
    "Marg ERP alternative",
    "Zoho Inventory alternative",
    "QuickBooks alternative",
    "Khatabook alternative",
  ],
} as const

export const seoKeywordDatabase = {
  // ========================================================================
  // 1. COMPETE & SWITCH KEYWORDS (Vyapar/Tally/myBillBook/Busy/Swipe Dissatisfaction)
  // Targeting frustrated users searching for alternatives
  // ========================================================================
  competeAndSwitch: {
    vyaparAlternatives: [
      "vyapar alternative for small shop",
      "vyapar alternative 2025",
      "vyapar alternative cheaper",
      "vyapar alternative free",
      "vyapar better alternative",
      "vyapar app alternative",
      "vyapar app koi alternative hai",
      "vyapar billing software alternative",
      "vyapar cost effective alternative",
      "vyapar expensive alternative",
      "vyapar Feature missing alternative",
      "vyapar slow alternative",
      "vyapar sync issue alternative",
      "vyapar vs better software",
      "bad alternative to vyapar",
      "best vyapar alternative India",
      "cheap vyapar alternative",
      "free vyapar alternative app",
      "good alternative to vyapar",
      "hidden charges in vyapar alternative",
      "low cost vyapar alternative",
      "no hidden charges vyapar alternative",
      "offline vyapar alternative",
      "唯一一家 vyapar alternative",
      "perfect vyapar alternative",
      "real vyapar alternative",
      "superior to vyapar",
      "top vyapar alternative 2025",
      "true vyapar alternative",
      "ultimate vyapar alternative",
      "unlimited vyapar alternative",
      "versus vyapar better software",
      "what is better than vyapar",
      "working vyapar alternative",
      "vyapar app ki jagah kya use karu",
      "vyapar ki best alternative",
      "vyapar ki jagah kya chal raha hai",
      "vyapar ki sasti alternative",
      "vyapar se acha billing software",
      "vyapar se behtar software",
      "vyapar se sasta billing app",
      "vyapar subscription badh gaya alternative",
      "vyapar unlimited billing alternative",
      "vyapar yearly price badh gaya alternative",
      // Vyapar complaints: Pricing
      "vyapar price badh gaya alternative",
      "vyapar pricing complaint alternative",
      "vyapar expensive 2025 alternative",
      "vyapar yearly renewal cost too high",
      "vyapar hidden renewal charges",
      "vyapar subscription moot price",
      "vyapar not affordable for small shop",
      "vyapar pricing increased 2025",
      "vyapar yearly plan cost increased",
      "vyapar auto renewal charges hidden",
      // Vyapar complaints: Technical
      "vyapar slow performance alternative",
      "vyapar lagging issue alternative",
      "vyapar sync problem mobile desktop",
      "vyapar data sync not working",
      "vyapar cloud sync issue",
      "vyapar offline mode not working",
      "vyapar app crashes frequently",
      "vyapar freezing issue",
      "vyapar data loss issue",
      "vyapar backup not working",
      "vyapar GST calculation wrong",
      "vyapar invoice printing issue",
      "vyapar multi device sync fail",
      "vyapar mobile app not stable",
      "vyapar desktop version buggy",
      // Vyapar complaints: Features
      "vyapar missing features alternative",
      "vyapar limited features alternative",
      "vyapar no stock alert feature",
      "vyapar no expiry tracking",
      "vyapar no low stock alert",
      "vyapar inventory management weak",
      "vyapar supplier management bad",
      "vyapar customer ledger weak",
      "vyapar payment reminder not working",
      "vyapar WhatsApp invoice not working",
      "vyapar e-invoice not working",
      "vyapar e-way bill issue",
      "vyapar multi currency not working"
    ],
    tallyAlternatives: [
      "tally alternative for small shop",
      "tally alternative cheap",
      "tally alternative free",
      "tally alternative for kirana",
      "tally alternative mobile app",
      "tally cloud alternative",
      "tally cracked version alternative legal",
      "tally expensive alternative",
      "tally gst alternative cheaper",
      "tally prime alternative affordable",
      "tally prime alternative cloud",
      "tally prime alternative free",
      "tally prime alternative mobile",
      "tally prime alternative online",
      "tally prime alternative offline",
      "tally prime alternative roku",
      "tally prime alternative sasta",
      "tally prime koi accha alternative",
      "tally prime se sasta accounting software",
      "tally se behtar software chhote dukan ke liye",
      "tally se sasta billing software",
      "tally alternative no installation",
      "tally alternative online cloud",
      "tally alternative without license",
      "best alternative to tally for small business",
      "cheap tally alternative India",
      "cost effective tally alternative",
      "free tally alternative for shop",
      "lightweight tally alternative",
      "modern tally alternative",
      "online tally alternative",
      "simple tally alternative",
      "tally accounting alternative mobile",
      "tally.app alternative",
      "tally cracked version legal alternative",
      "tally for small shop alternative",
      "tally license cost alternative",
      "tally license expensive alternative",
      "tally not for small shop alternative",
      "tally overkill for small business alternative",
      "tally pricing too high alternative",
      "tally prime affordable alternative",
      "tally prime best alternative",
      "tally prime cloud alternative",
      "tally prime cost alternative",
      "tally prime expensive alternative",
      "tally prime for kirana shop alternative",
      "tally prime license cost alternative",
      "tally prime mobile app alternative",
      "tally prime online alternative",
      "tally prime price badh gaya",
      "tally prime price high alternative",
      "tally prime replacement",
      "tally prime sasta alternative",
      "tally prime se accha software",
      "tally prime se behtar option",
      "tally prime se sasta software",
      "tally prime simple alternative",
      "tally prime small business alternative",
      "tally upgrade cost alternative",
      "what is better than tally for small shop",
      "zoho books vs tally alternative",
      "tally ki jagah kya use karu chhote dukan ke liye",
      "tally se simple billing software",
      "tally matra style nahi chahie simple app"
    ],
    mybillbookAlternatives: [
      "mybillbook alternative cheaper",
      "mybillbook alternative free",
      "mybillbook app alternative",
      "mybillbook billing software alternative",
      "mybillbook expensive alternative",
      "mybillbook limitation alternative",
      "mybillbook price badh gaya",
      "mybillbook se sasta billing app",
      "alternative to mybillbook for small shop",
      "best mybillbook alternative",
      "cheap mybillbook alternative",
      "free mybillbook alternative",
      "mybillbook 2025 alternative",
      "mybillbook alternative India",
      "mybillbook alternative no subscription",
      "mybillbook alternative without internet",
      "good alternative to mybillbook"
    ],
    busyAlternatives: [
      "busy accounting software alternative",
      "busy accounting alternative cheaper",
      "busy alternative for kirana shop",
      "busy alternative for small shop",
      "busy alternative free",
      "busy alternative mobile app",
      "busy alternative online",
      "busy alternative sasta",
      "busy alternative small business",
      "busy cheap alternative",
      "busy free alternative India",
      "busy software alternative affordable",
      "busy vs vyapar better alternative",
      "alternative to busy for small retailer"
    ],
    swipeAlternatives: [
      "swipe billing app alternative",
      "swipe app alternative cheaper",
      "swipe alternative free",
      "swipe billing software alternative",
      "alternative to swipe for small shop",
      "best swipe alternative",
      "cheap swipe alternative",
      "free swipe alternative"
    ],
    generalSwitchKeywords: [
      "billing software switching from vyapar",
      "billing software switching from tally",
      "change billing software from vyapar",
      "change from tally to cheaper software",
      "dissatisfied with vyapar what to use",
      "escape vyapar subscription trap",
      "keep billing data when switching software",
      "migrate from vyapar to another app",
      "switch from mybillbook to cheaper",
      "switch from tally to cloud software",
      "switch billing software India",
      "why switch from vyapar",
      "why switch from tally"
    ]
  },

  // ========================================================================
  // 2. RETAIL & SHOP SPECIFIC LONG-TAIL KEYWORDS (Micro-Industry Breakdown)
  // ========================================================================
  retailAndShopSpecific: {
    kiranaGrocery: [
      "kirana store billing software",
      "kirana store management software",
      "kirana store stock management app",
      "grocery shop billing software",
      "grocery shop management software",
      "grocery store inventory app",
      "small grocery store billing app",
      "dukan ka stock manager",
      "dukan ka bill banane ka app",
      "dukan ka hisab kitab app",
      "dukan ka khata app",
      "chhote dukan ke liye billing software",
      "chhote kirana ke liye billing app",
      "chhote dukan billing software free",
      "kirana store billing app free download",
      "kirana store stock tracking app",
      "kirana inventory management app",
      "kirana dukan hisab kitab app",
      "kirana stock manager app",
      "grocery billing app for small shop",
      "grocery shop GST billing app",
      "grocery store billing software India",
      "small kirana billing software affordable",
      "best billing software for kirana store",
      "best inventory app for grocery shop",
      "chhote kirana store ke liye accha app",
      "kirana store GST billing software",
      "kirana store mobile billing app",
      "kirana stock register app",
      "grocery shop stock manager app",
      "grocery store khata hisab app",
      "kirana dukan ka bill app",
      "kirana dukan ka hisab app",
      "kirana dukan ka stock app",
      "grocery dukan ka billing app",
      "grocery store ka billing software",
      "kirana billing app offline",
      "grocery billing app offline",
      "kirana store app without internet",
      "grocery shop app without internet",
      "bina internet chalne wala billing app kirana",
      "offline kirana billing software",
      "offline grocery billing app",
      "kirana store billing software no internet",
      "grocery billing software no internet needed",
      "kirana stock management without internet",
      "grocery inventory without internet",
      "kirana store stock management offline",
      "grocery store billing offline app",
      "kirana app jo bina internet pe chale",
      "grocery app jo bina internet ke chale",
      "kirana store low cost billing software",
      "grocery shop low cost billing app",
      "cheapest billing software for kirana",
      "most affordable grocery billing app",
      "kirana store billing under 100 rupees",
      "grocery billing app under 100 rupees",
      "kirana billing software monthly 99 rupees",
      "grocery billing monthly subscription cheap",
      "best budget billing app for kirana",
      "kirana store economical billing software",
      "grocery shop budget billing app",
      "kirana store affordable GST billing",
      "grocery store budget GST billing app",
      "kirana shop stock alert app",
      "grocery store stock alert software",
      "kirana low stock alert app",
      "grocery low stock warning app",
      "kirana expiry tracking app",
      "grocery expiry date tracker app",
      "kirana store dated product manager",
      "grocery store expiry management app",
      "kirana store customer ledger app",
      "grocery shop customer account app",
      "kirana dukan customer khata app",
      "grocery dukan khata hisab app",
      "kirana store supplier bill app",
      "grocery shop supplier billing app",
      "kirana purchase order app",
      "grocery purchase manager app",
      "kirana store daily sales app",
      "grocery shop daily sale tracker",
      "kirana dukan daily profit app",
      "grocery dukan daily profit tracker",
      "kirana store profit loss app",
      "grocery shop profit loss calculator",
      "kirana dukan ka profit hisab app",
      "grocery dukan ka profit loss app",
      "kirana GST invoice maker app",
      "grocery GST bill generator app",
      "kirana store WhatsApp bill app",
      "grocery shop WhatsApp invoice app",
      "kirana dukan WhatsApp par bill bane",
      "grocery dukan WhatsApp invoice bane",
      "kirana store printable bill app",
      "grocery shop printable invoice app",
      "kirana dukan bill print karne ka app",
      "grocery dukan invoice print app"
    ],
    hardwareSanitary: [
      "hardware shop billing software",
      "hardware store management software",
      "hardware shop inventory app",
      "hardware store stock manager",
      "sanitary shop billing software",
      "sanitary store management app",
      "sanitary shop stock tracking",
      "plumbing shop billing software",
      "paint shop billing software",
      "paint store inventory app",
      "pipes shop billing software",
      "tiles shop billing software",
      "cement shop billing software",
      "iron shop billing software",
      "steel shop billing software",
      "hardware dukan billing app",
      "hardware store GST billing",
      "hardware shop stock register",
      "sanitary dukan billing software",
      "sanitary store GST billing app",
      "plumbing material billing app",
      "paint billing app for shop",
      "pipes inventory management app",
      "tiles shop stock manager app",
      "cement shop stock tracking",
      "iron shop inventory app",
      "steel store billing software",
      "hardware shop low stock alert",
      "sanitary shop stock alert app",
      "hardware store supplier bill",
      "sanitary shop supplier billing",
      "hardware shop daily sales tracker",
      "hardware store profit calculator",
      "hardware shop WhatsApp bill",
      "hardware store printable invoice",
      "hardware dukan ka hisab kitab",
      "hardware shop khata hisab app",
      "sanitary dukan ka billing app",
      "sanitary shop khata app",
      "best billing software for hardware shop",
      "best inventory app for hardware store",
      "cheap billing software for hardware",
      "affordable stock manager for hardware",
      "hardware shop billing under 100",
      "hardware store billing monthly 99",
      "offline billing app for hardware shop",
      "hardware shop billing without internet",
      "bina internet chalne wala hardware billing",
      "hardware shop GST invoice maker",
      "hardware store WhatsApp invoice",
      "hardware shop customer ledger",
      "hardware dukan customer khata",
      "hardware shop purchase order app",
      "hardware store supplier manager",
      "hardware shop daily profit tracker",
      "best GST billing for hardware store",
      "hardware shop economical billing",
      "hardware store budget billing app"
    ],
    mobileElectronics: [
      "mobile shop billing software",
      "mobile store management app",
      "mobile shop inventory tracking",
      "mobile shop stock manager",
      "electronics shop billing software",
      "electronics store inventory app",
      "electronics shop stock tracking",
      "mobile accessories billing app",
      "electronics accessories billing",
      "battery shop billing software",
      "inverter shop billing software",
      "automobile spare parts billing",
      "tyre shop billing software",
      "mobile workshop billing software",
      "mobile repair shop billing",
      "electronics repair shop billing",
      "mobile dukan billing app",
      "mobile store GST billing",
      "mobile shop stock register app",
      "electronics dukan billing software",
      "electronics store GST billing",
      "mobile accessories stock app",
      "electronics accessories inventory",
      "battery shop stock tracker",
      "inverter shop stock manager",
      "automobile parts inventory app",
      "tyre shop stock tracking",
      "mobile workshop stock app",
      "mobile repair billing app",
      "electronics repair billing",
      "mobile shop low stock alert",
      "electronics shop stock alert",
      "mobile store supplier billing",
      "electronics supplier bill app",
      "mobile shop daily sales",
      "electronics shop profit tracker",
      "mobile shop WhatsApp bill",
      "electronics shop WhatsApp invoice",
      "mobile dukan ka billing app",
      "mobile shop khata hisab",
      "electronics dukan billing app",
      "electronics shop khata app",
      "best billing software for mobile shop",
      "best inventory for mobile store",
      "cheap billing for mobile accessories",
      "affordable stock for electronics",
      "mobile shop billing under 100",
      "electronics shop billing monthly 99",
      "offline billing for mobile shop",
      "mobile shop billing without internet",
      "bina internet chalne wala mobile billing",
      "mobile shop GST invoice maker",
      "electronics shop WhatsApp invoice",
      "mobile shop customer ledger",
      "mobile dukan customer khata",
      "mobile shop purchase order",
      "electronics supplier manager",
      "mobile shop daily profit",
      "best GST billing for electronics",
      "mobile shop economical billing",
      "electronics store budget billing"
    ],
    wholesalersGodowns: [
      "wholesaler billing software India",
      "wholesale shop management software",
      "wholesaler inventory tracking",
      "wholesaler stock manager",
      "godown billing software",
      "godown management app",
      "godown stock tracking",
      "warehouse billing software",
      "warehouse inventory app",
      "warehouse stock manager",
      "distributor billing software",
      "distributor inventory app",
      "distributor stock tracking",
      "stockist billing software",
      "stockist inventory app",
      "showroom billing software",
      "showroom management app",
      "storekeeper billing software",
      " wholesalers bil app",
      "wholesale dukan billing app",
      "wholesale store GST billing",
      "wholesaler stock register",
      "godown dukan billing software",
      "godown store GST billing",
      "warehouse stock app",
      "distributor stock app",
      "distributor billing app",
      "stockist stock tracking",
      "showroom stock manager",
      "storekeeper stock app",
      "wholesaler low stock alert",
      "godown stock alert app",
      "warehouse supplier bill",
      "distributor supplier billing",
      "wholesaler daily sales",
      "godown profit tracker",
      "wholesaler WhatsApp bill",
      "godown WhatsApp invoice",
      "wholesale dukan ka billing",
      "wholesaler khata hisab",
      "godown dukan billing app",
      "godown khata app",
      "best billing for wholesaler",
      "best inventory for godown",
      "cheap billing for warehouse",
      "affordable stock for distributor",
      "wholesaler billing under 100",
      "godown billing monthly 99",
      "offline billing for wholesaler",
      "wholesaler billing without internet",
      "bina internet chalne wala godown billing",
      "wholesaler GST invoice",
      "godown WhatsApp invoice",
      "wholesaler customer ledger",
      "wholesale dukan customer khata",
      "wholesaler purchase order",
      "godown supplier manager",
      "wholesaler daily profit",
      "best GST for wholesaler",
      "wholesaler economical billing",
      "godown budget billing app"
    ],
    clothingGarments: [
      "clothing shop billing software",
      "garment shop billing software",
      "clothing store management app",
      "garment store inventory app",
      "clothes shop stock manager",
      "garments stock tracking",
      "fashion shop billing software",
      "apparel shop billing",
      "clothing dukan billing app",
      "garment dukan billing",
      "clothing store GST billing",
      "garment store GST",
      "clothes shop stock app",
      "garments stock app",
      "fashion dukan billing",
      "apparel dukan billing",
      "clothing shop low stock",
      "garment shop stock alert",
      "clothing supplier billing",
      "garment supplier bill",
      "clothing daily sales",
      "garment profit tracker",
      "clothing WhatsApp bill",
      "garment WhatsApp invoice",
      "clothing dukan ka billing",
      "garment dukan khata",
      "clothes shop billing app",
      "garments shop billing",
      "best billing for clothing shop",
      "best inventory for garment",
      "cheap billing for clothes",
      "affordable stock for fashion",
      "clothing billing under 100",
      "garment billing monthly 99",
      "offline billing for clothing",
      "clothing billing without internet",
      "bina internet chalne wala garment billing",
      "clothing GST invoice",
      "garment WhatsApp invoice",
      "clothing customer ledger",
      "clothing dukan customer khata",
      "clothing purchase order",
      "garment supplier manager",
      "clothing daily profit",
      "best GST for clothing",
      "clothing economical billing",
      "garment budget billing"
    ]
  },

  // ========================================================================
  // 3. INTENT & FEATURE BASED KEYWORDS (Feature + Affordability)
  // ========================================================================
  intentAndFeatureBased: {
    affordabilityKeywords: [
      "GST billing app under 100 rupees",
      "GST billing software under 100",
      "billing software under 100 rupees monthly",
      "billing app monthly 99 rupees",
      "billing software monthly 99 rupees",
      "cheapest billing software India",
      "most affordable billing app India",
      "low cost billing software for shop",
      "budget billing software for small business",
      "economical billing app for shop",
      "cheap GST billing software India",
      "affordable GST billing app",
      "billing software under 500 rupees",
      "billing app under 1000 rupees yearly",
      "billing software yearly 999 rupees",
      "GST billing yearly 999 rupees",
      "billing software per month 3 rupees",
      "billing app daily cost 3 rupees",
      "most cost effective billing software",
      "billing software best value India",
      "billing app great value cheap",
      "billing software no hidden charges",
      "billing app transparent pricing",
      "billing software one time payment",
      "billing app lifetime license cheap",
      "billing software permanent license",
      "billing app without subscription",
      "billing software pay once use forever",
      "billing app cheapest in India",
      "GST billing cheapest app",
      "inventory software under 100 monthly",
      "stock management under 100 rupees",
      "shop billing under 100 per month",
      "store billing monthly cost low",
      "retail billing cheapest software",
      "wholesale billing affordable",
      "small shop billing cheapest",
      "kirana billing most affordable",
      "hardware billing low cost",
      "electronics billing budget",
      "clothing billing economical"
    ],
    featureBasedKeywords: [
      "mobile and PC automatic sync software",
      "mobile desktop sync billing app",
      "automatic sync billing software",
      "cloud sync billing app India",
      "billing app mobile computer sync",
      "stock sync mobile desktop",
      "inventory sync mobile PC",
      "automatic backup billing app",
      "auto backup billing software",
      "billing app data backup",
      "billing software cloud backup",
      "low stock alert software retail",
      "low stock warning billing app",
      "stock alert inventory app",
      "notify low stock billing",
      "minimum stock alert software",
      "expiry date tracking billing app",
      "expiry tracking inventory software",
      "product expiry manager app",
      "dated product tracking billing",
      "bill on WhatsApp billing app",
      "WhatsApp invoice billing software",
      "send bill WhatsApp billing",
      "WhatsApp par bill bane app",
      "printable billing app shop",
      "print bill billing software",
      "invoice print billing app",
      "GST invoice maker billing",
      "GST bill generator app",
      "GST invoice billing software",
      "customer ledger billing app",
      "customer account billing software",
      "khata hisab billing app",
      "supplier billing management app",
      "purchase order billing software",
      "daily sales tracking billing",
      "daily profit calculator billing",
      "profit loss billing app",
      "sales report billing software",
      "inventory report billing app",
      "stock report billing software",
      "multi item billing app",
      "single sale billing software",
      "multiple products billing app",
      "bulk billing software shop",
      "bulk invoice billing app",
      "customer wise billing report",
      "product wise sales report",
      "category wise inventory report",
      "stock value billing app",
      "stock movement billing software"
    ],
    offlineAndSyncKeywords: [
      "bina internet chalne wala billing app",
      "offline billing app India",
      "offline billing software shop",
      "billing app without internet",
      "billing software no internet",
      "offline GST billing app",
      "offline stock manager app",
      "offline inventory app India",
      "no internet billing software",
      "internet nahi chahiye billing",
      "offline mode billing app",
      "offline billing for small shop",
      "offline kirana billing",
      "offline hardware billing",
      "offline mobile shop billing",
      "offline wholesaler billing",
      "offline garment billing",
      "billing app rural area India",
      "billing software low internet area",
      "billing app network nahi hai",
      "billing software offline first",
      "offline billing mobile app",
      "offline billing desktop app",
      "offline billing both mobile PC",
      "offline sync billing later cloud",
      "offline billing auto sync internet",
      "offline billing backup internet"
    ],
    gstAndComplianceKeywords: [
      "GST billing app India small shop",
      "GST invoice app for shop",
      "GST bill maker for small business",
      "GST compliant billing software",
      "GST ready billing app",
      "GST invoice generator free",
      "GST billing software free trial",
      "GST invoice mobile app",
      "GST bill mobile app",
      "GST billing desktop software",
      "small shop GST billing",
      "kirana GST billing app",
      "retail GST billing software",
      "wholesale GST billing",
      "GST e-invoice billing app",
      "GST e-way bill billing",
      "GST billing with e-invoice",
      "GST billing India 2025",
      "new GST billing rules app",
      "updated GST billing software"
    ]
  },

  // ========================================================================
  // 4. REVENUE-DRIVING QUESTIONS (FAQ Keywords)
  // ========================================================================
  faqQuestions: [
    "which billing software is best for small shop in India",
    "what is the cheapest billing software for kirana store",
    "how to make GST bill for small shop",
    "which billing app works without internet",
    "what is the best inventory app for small shop",
    "how to manage stock in kirana store",
    "which software is best for hardware shop billing",
    "what billing app do mobile shops use",
    "how to track low stock in shop",
    "which app shows expiry date of products",
    "how to send bill on WhatsApp for shop",
    "what is the best billing software under 100 rupees",
    "which billing software has mobile and PC sync",
    "how to make daily profit report of shop",
    "what is the best GST billing app for small business",
    "which billing app is free for small shop",
    "how to manage customer khata in shop",
    "what software do wholesalers use for billing",
    "which billing app is best for garment shop",
    "how to track supplier bills in shop",
    "what is the best inventory management for kirana",
    "which billing software is easy to use for shop",
    "how to print bill from mobile for shop",
    "what is the cost of Billing software for small shop",
    "which billing app has no hidden charges",
    "how to switch from Vyapar to another billing app",
    "what is better than Tally for small shop",
    "which billing software works offline and online",
    "how to backup billing data of shop",
    "what is the best billing software for godown",
    "which app is best for wholesale business billing",
    "how to manage purchase order in shop",
    "what billing software has stock alert feature",
    "which is the most affordable GST billing app",
    "how to track daily sales of shop automatically",
    "what is the best billing software for electronics shop",
    "which billing app supports WhatsApp invoice",
    "how to calculate profit and loss of shop",
    "what billing software is best for painting shop",
    "which app is used for sanitary shop billing",
    "how to manage customer ledger in billing app",
    "what is the yearly cost of billing software India",
    "which billing software is best for pipes shop",
    "how to track cement stock in hardware shop",
    "what billing app works for tyre shop",
    "which software is best for battery shop billing",
    "how to manage inverter shop inventory",
    "what billing app is best for automobile parts",
    "which software for tiles shop stock management",
    "how to track iron and steel shop inventory",
    "what is the best billing for fashion store",
    "which app is best for clothes shop billing",
    "how to manage apparel shop inventory",
    "what billing software for furniture shop",
    "which app for jewelry shop billing India",
    "how to track book shop inventory",
    "what billing for pharmacy shop India",
    "which software for medicine shop billing",
    "how to manage medicine expiry in shop",
    "what billing app for food shop India",
    "which software for restaurant billing small",
    "how to track cafe inventory small",
    "what billing for tea stall shop India",
    "which app for street food billing",
    "how to manage small dukan billing",
    "what is easiest billing app for new shop",
    "which billing software for first time shop owner",
    "how to start billing in new shop easily",
    "what billing app requires no training",
    "which software is simple for shop billing",
    "how to learn billing software quickly shop",
    "what is user friendly billing app India",
    "which billing app has Hindi support",
    "how to use billing app in regional language",
    "what billing software supports multiple languages",
    "which app is best for shop with 1 employee",
    "how to manage billing for shop with 2 workers",
    "what billing for shop with multiple counters",
    "which software for shop with multiple brands",
    "how to track sales at different counters",
    "what billing for shop morning to night",
    "which app for shop open 7 days",
    "how to manage billing long hour shop",
    "what for shop with high daily sales",
    "which billing for shop 100+ customers daily",
    "how to manage peak hour billing fast",
    "what billing for quick service shop",
    "which app for fast checkout shop",
    "how to speed up billing in shop"
  ],

  // ========================================================================
  // 5. HINGLISH & REGIONAL KEYWORDS (Critical for Indian Market)
  // ========================================================================
  hinglishAndRegional: [
    "dukan ka bill banane ka app",
    "dukan ka hisab kitab app",
    "dukan ka khata app",
    "dukan ka stock manager",
    "chhote dukan ke liye billing software",
    "chhote kirana ke liye billing app",
    "chhote dukan billing software free",
    "kirana dukan hisab kitab app",
    "kirana dukan ka bill app",
    "kirana dukan ka hisab app",
    "kirana dukan ka stock app",
    "grocery dukan ka billing app",
    "grocery dukan ka bill banane ka app",
    "hardware dukan billing app",
    "hardware dukan ka hisab kitab",
    "hardware dukan ka billing app",
    "sanitary dukan ka billing app",
    "sanitary dukan ka billing",
    "mobile dukan billing app",
    "mobile dukan ka billing app",
    "mobile dukan ka billing",
    "electronics dukan billing app",
    "electronics dukan ka billing",
    "clothing dukan billing app",
    "garment dukan billing",
    "garment dukan ka billing",
    "wholesale dukan billing app",
    "wholesale dukan ka billing",
    "godown dukan billing software",
    "godown dukan ka billing",
    "bina internet chalne wala billing app",
    "internet nahi chahiye billing",
    "network nahi hai billing app",
    "dukan ki billing kaise kare",
    "dukan ka hisab kaise rakhe",
    "dukan ka stock kaise manage kare",
    "kirana ki billing kaise kare",
    "kirana ka hisab kaise rakhe",
    "chhote dukan ki billing app",
    "chhote dukan ka billing software",
    "dukan accha billing app kya hai",
    "dukan best billing software kya hai",
    "kirana accha billing app kya hai",
    "hardware accha billing app kya hai",
    "mobile shop accha billing kya hai",
    "electronics accha billing kya hai",
    "garment accha billing kya hai",
    "wholesale accha billing kya hai",
    "godown accha billing kya hai",
    "dukan ka billing software sasta kya hai",
    "dukan ka billing app sasta kya hai",
    "kirana sasta billing app kya hai",
    "hardware sasta billing kya hai",
    "mobile shop sasta billing kya hai",
    "billing software monthly 99 rupees kya acha hai",
    "billing app yearly 999 kya best hai",
    "dukan billing software 100 rupaye se kam",
    "billing app 100 rupaye mein",
    "chhote dukan billing 100 rupees",
    "kirana billing 100 rupees monthly",
    "dukan billing software kitne ka hai",
    "billing app ka price kya hai",
    "billing software ki cost kya hai",
    "GST billing app free kya hai",
    "billing software free trial kya hai",
    "dukan billing app test kaise kare",
    "billing software demo kaise le",
    "billing app free mein kaise use kare",
    "dukan billing software 14 day free",
    "kirana billing 14 days free",
    "dukan billing app try kaise kare",
    "billing software kaise download kare",
    "billing app kaise install kare",
    "dukan billing software mobile mein kaise lagaye",
    "billing app computer mein kaise chale",
    "dukan billing mobile PC sync kaise kare",
    "billing app automatic sync kaise kare",
    "dukan billing auto backup kaise kare",
    "billing software data kaise save kare",
    "dukan billing data protect kaise kare",
    "billing app stock kaise track kare",
    "dukan stock alert kaise lage",
    "billing software low stock kaise bataye",
    "dukan expiry kaise track kare",
    "billing app expiry date kaise dekhe",
    "dukan WhatsApp bill kaise bheje",
    "billing software WhatsApp par kaise share kare",
    "dukan bill print kaise kare",
    "billing app se bill print kaise ho",
    "dukan GST bill kaise banaye",
    "billing software GST invoice kaise khe",
    "dukan customer khata kaise rakhe",
    "billing app customer ledger kaise banaye",
    "dukan supplier bill kaise mange",
    "billing software supplier kaise manage kare",
    "dukan purchase order kaise le",
    "billing app purchase kaise track kare",
    "dukan daily sales kaise dekhe",
    "billing software daily profit kaise dekhe",
    "dukan profit loss kaise jane",
    "billing app daily report kaise mile",
    "dukan sales report kaise nikale",
    "billing software stock report kaise mile",
    "dukan inventory report kaise dekhe"
  ],

  // ========================================================================
  // 6. COMPETITOR COMPARISON KEYWORDS
  // ========================================================================
  competitorComparison: [
    "vyapar vs dugam billing",
    "tally vs dugam small shop",
    "mybillbook vs dugam",
    "busy vs dugam billing",
    "swipe vs dugam app",
    "vyapar or dugam which is better",
    "tally or dugam for kirana",
    "mybillbook or dugam cheaper",
    "dugam vs vyapar pricing",
    "dugam vs tally features",
    "dugam vs mybillbook reviews",
    "why choose dugam over vyapar",
    "why choose dugam over tally",
    "dugam better than vyapar",
    "dugam better than tally",
    "dugam better than mybillbook",
    "dugam cheaper than vyapar",
    "dugam cheaper than tally",
    "dugam cheaper than mybillbook",
    "dugam vs vyapar 2025",
    "dugam vs tally 2025",
    "best billing software dugam vyapar tally",
    "top billing software dugam comparison",
    "dugam billing software review India",
    "is dugam billing app good",
    "dugam billing app worth it",
    "dugam billing software honest review"
  ],

  // ========================================================================
  // 7. CONVERSION & TRAFFIC DRIVERS
  // ========================================================================
  conversionTraffic: [
    "free trial billing software India",
    "14 day free trial billing app",
    "billing software free download India",
    "billing app free trial no credit",
    "try billing software free before buy",
    "billing software demo download",
    "billing app trial version free",
    "start billing software free",
    "billing software no commitment",
    "billing app cancel anytime",
    "billing software monthly plan India",
    "billing app yearly plan cheap",
    "billing software 999 rupees yearly",
    "billing app 99 rupees monthly",
    "billing software subscribe monthly",
    "billing app subscribe yearly",
    "billing software best deal India",
    "billing app great offer 2025",
    "billing software discount India",
    "billing app sale 2025",
    "billing software new customer offer",
    "billing app first time user discount",
    "billing software shop owner deal",
    "billing app kirana special offer",
    "billing software wholesale deal",
    "billing app retail special",
    "billing software hardware offer",
    "billing app electronics deal",
    "billing app garment offer",
    "billing software best value 2025",
    "billing app top rated India",
    "billing software customer favorite",
    "billing app most popular India",
    "billing software trusted by shops",
    "billing app recommended by retailers",
    "billing software shop owners choose",
    "billing app Indian retailers use"
  ]
};

export const seoKeywordSources = {
  competitorReviews: [
    "LinkedIn: Top 7 Billing & Invoicing Software India - Vyapar lacks advanced features, slow performance, limited multi-currency [web:50]",
    "Reddit IndiaBusiness: myBillBook simple but users seeking alternatives [web:54]",
    "TallyAtCloud: Tally alternatives for SMEs - Zoho Books, Vyapar preferred for simplicity [web:52]",
    "Takkada: Vyapar alternative for distributors - Tally-connected mobile platforms [web:56]"
  ],
  searchTrends: [
    "Google Play Store: GST billing app India, VAT billing, invoice generator, mobile billing app keywords [web:53]",
    "StockRegister: Inventory management for kirana shop focus [web:59]",
    "BillingFast: Best billing software India complete comparison [web:58]"
  ],
  industryInsights: [
    "Unicommerce: Best inventory management India - Zoho, Odoo for SMB, SAP for enterprise [web:51]",
    "Busy.in: India's trusted accounting & GST billing for SMBs [web:57]",
    "DigifySoft: Cloud-based kirana store management software top 10 [web:55]"
  ]
};



export type SeoKeywordRouteRule = {
  label: string
  paths: readonly string[]
  keywords: readonly string[]
}

function normalizeSeoRoutePath(routePath: string) {
  if (!routePath || routePath === "#") return "/"
  const strippedPath = routePath.split("?")[0].split("#")[0]
  if (!strippedPath || strippedPath === "/") return "/"
  return `/${strippedPath.replace(/^\/+|\/+$/g, "")}`
}

function collectSeoKeywordValues(value: unknown, collected: string[]) {
  if (typeof value === "string") {
    collected.push(value)
    return
  }

  if (Array.isArray(value)) {
    for (const entry of value) {
      collectSeoKeywordValues(entry, collected)
    }
    return
  }

  if (value && typeof value === "object") {
    for (const nestedValue of Object.values(value as Record<string, unknown>)) {
      collectSeoKeywordValues(nestedValue, collected)
    }
  }
}

export function flattenSeoKeywordDatabase(database: unknown = seoKeywordDatabase) {
  const keywords: string[] = []
  collectSeoKeywordValues(database, keywords)
  return Array.from(new Set(keywords))
}

export const allSeoKeywords = Array.from(
  new Set([
    ...flattenSeoKeywordDatabase(),
    ...dugamSEOData.primaryKeywords,
    ...dugamSEOData.businessKeywords,
    ...dugamSEOData.pricingKeywords,
    ...dugamSEOData.competitorKeywords,
  ]),
)

export const programmaticKeywordRouteRules: SeoKeywordRouteRule[] = [
  {
    label: "Vyapar alternative searches",
    paths: ["/alternatives", "/alternatives/vyapar"],
    keywords: seoKeywordDatabase.competeAndSwitch.vyaparAlternatives,
  },
  {
    label: "Tally alternative searches",
    paths: ["/alternatives", "/alternatives/tally"],
    keywords: seoKeywordDatabase.competeAndSwitch.tallyAlternatives,
  },
  {
    label: "myBillBook alternative searches",
    paths: ["/alternatives", "/alternatives/mybillbook"],
    keywords: seoKeywordDatabase.competeAndSwitch.mybillbookAlternatives,
  },
  {
    label: "Busy alternative searches",
    paths: ["/alternatives", "/alternatives/busy"],
    keywords: seoKeywordDatabase.competeAndSwitch.busyAlternatives,
  },
  {
    label: "Swipe alternative searches",
    paths: ["/alternatives", "/alternatives/swipe"],
    keywords: seoKeywordDatabase.competeAndSwitch.swipeAlternatives,
  },
  {
    label: "General switch intent",
    paths: ["/alternatives"],
    keywords: seoKeywordDatabase.competeAndSwitch.generalSwitchKeywords,
  },
  {
    label: "Kirana and grocery workflows",
    paths: ["/industries", "/industries/kirana-store"],
    keywords: seoKeywordDatabase.retailAndShopSpecific.kiranaGrocery,
  },
  {
    label: "Hardware and sanitary workflows",
    paths: ["/industries", "/industries/hardware-shop"],
    keywords: seoKeywordDatabase.retailAndShopSpecific.hardwareSanitary,
  },
  {
    label: "Mobile and electronics workflows",
    paths: ["/industries", "/industries/electronics-and-mobile"],
    keywords: seoKeywordDatabase.retailAndShopSpecific.mobileElectronics,
  },
  {
    label: "Wholesale and godown workflows",
    paths: ["/industries", "/industries/wholesalers-and-godown"],
    keywords: seoKeywordDatabase.retailAndShopSpecific.wholesalersGodowns,
  },
  {
    label: "Clothing and garments workflows",
    paths: ["/industries", "/industries/clothing-garments"],
    keywords: seoKeywordDatabase.retailAndShopSpecific.clothingGarments,
  },
  {
    label: "Affordability queries",
    paths: ["/pricing"],
    keywords: seoKeywordDatabase.intentAndFeatureBased.affordabilityKeywords,
  },
  {
    label: "Feature-led queries",
    paths: ["/pricing", "/alternatives"],
    keywords: seoKeywordDatabase.intentAndFeatureBased.featureBasedKeywords,
  },
  {
    label: "Offline and sync queries",
    paths: ["/alternatives", "/support"],
    keywords: seoKeywordDatabase.intentAndFeatureBased.offlineAndSyncKeywords,
  },
  {
    label: "GST and compliance queries",
    paths: ["/pricing", "/faq"],
    keywords: seoKeywordDatabase.intentAndFeatureBased.gstAndComplianceKeywords,
  },
  {
    label: "FAQ questions",
    paths: ["/faq"],
    keywords: seoKeywordDatabase.faqQuestions,
  },
  {
    label: "Regional and Hinglish discovery",
    paths: ["/", "/pricing", "/alternatives", "/industries"],
    keywords: seoKeywordDatabase.hinglishAndRegional,
  },
  {
    label: "Competitor comparison intent",
    paths: ["/alternatives"],
    keywords: seoKeywordDatabase.competitorComparison,
  },
  {
    label: "Conversion traffic intent",
    paths: ["/pricing", "/login"],
    keywords: seoKeywordDatabase.conversionTraffic,
  },
]

export function getProgrammaticKeywordsForPath(routePath: string) {
  const normalizedPath = normalizeSeoRoutePath(routePath)
  const routeKeywords = programmaticKeywordRouteRules.flatMap((rule) =>
    rule.paths.some((candidatePath) => normalizeSeoRoutePath(candidatePath) === normalizedPath)
      ? rule.keywords
      : [],
  )
  return Array.from(new Set(routeKeywords))
}

export type SeoKeywordTier = "tier1" | "tier2" | "tier3"

export const seoKeywordRankingTiers: Record<SeoKeywordTier, readonly string[]> = {
  tier1: [
    "vyapar ki jagah kya use karu",
    "vyapar se sasta billing app",
    "offline vyapar alternative",
    "billing software under 100 rupees per month",
    "vyapar alternative for small shop",
    "vyapar app koi alternative hai",
    "kirana store billing software",
    "wholesale inventory software",
    "inventory software for MSME",
    "billing app 99 rupees monthly",
    "billing software 999 rupees yearly",
    "try billing software free before buy",
    "billing software no commitment",
    "gst billing software for small shops",
    "vyapar app alternative",
    "mybillbook alternative",
    "tallyprime alternative",
  ],
  tier2: [
    "best vyapar alternative India",
    "cheap vyapar alternative",
    "vyapar billing software alternative",
    "vyapar subscription badh gaya alternative",
    "vyapar yearly renewal cost too high",
    "vyapar sync issue alternative",
    "billing software for small business",
    "inventory software under 999 rupees",
    "affordable GST billing software",
    "budget inventory management software",
    "billing software under 1000 rupees",
    "gst software for small shops",
    "retail billing software",
    "warehouse management software",
    "shop management software",
    "quickbooks alternative",
    "zoho inventory alternative",
  ],
  tier3: [
    "billing software",
    "inventory software",
    "GST billing software",
    "inventory management software",
    "stock management app",
    "GST billing app",
    "POS software india",
    "invoice software india",
    "stock management software",
    "inventory billing software",
    "shop billing software with GST",
    "free GST billing software",
    "inventory management app",
    "stock inventory tracker",
    "purchase management software",
    "sales management software",
    "warehouse stock management app",
  ],
}

export function getSeoKeywordTier(keyword: string): SeoKeywordTier | null {
  const normalizedKeyword = keyword.trim().toLowerCase()
  if (seoKeywordRankingTiers.tier1.some((item) => item.toLowerCase() === normalizedKeyword)) return "tier1"
  if (seoKeywordRankingTiers.tier2.some((item) => item.toLowerCase() === normalizedKeyword)) return "tier2"
  if (seoKeywordRankingTiers.tier3.some((item) => item.toLowerCase() === normalizedKeyword)) return "tier3"
  return null
}


export type ProgrammaticLink = {
  label: string
  href: string
  description?: string
}

export type ProgrammaticFaq = {
  question: string
  answer: string
}

export type ComparisonRow = {
  feature: string
  dugam: string
  competitor: string
}

export type CompetitorComparisonPageConfig = {
  kind: "competitor"
  slug: string
  competitorName: string
  title: string
  description: string
  h1: string
  intro: string
  comparisonHeadline: string
  comparisonNote: string
  comparisonRows: ComparisonRow[]
  highlights: string[]
  faqs: ProgrammaticFaq[]
  relatedLinks: ProgrammaticLink[]
}

export type IndustryPageConfig = {
  kind: "industry"
  slug: string
  industryName: string
  title: string
  description: string
  h1: string
  intro: string
  highlights: string[]
  useCases: string[]
  faqs: ProgrammaticFaq[]
  relatedLinks: ProgrammaticLink[]
}

const competitorComparisonRows: ComparisonRow[] = [
  {
    feature: "Multi-device sync",
    dugam: "Built for mobile + desktop workflows with a single inventory source of truth",
    competitor: "Often placed behind a higher-tier desktop sync plan",
  },
  {
    feature: "GST billing",
    dugam: "Included for Indian shop billing and invoice workflows",
    competitor: "Available, but frequently tied to setup complexity or premium modules",
  },
  {
    feature: "Pricing clarity",
    dugam: "₹99/month and ₹999/year with a clear daily-cost hook",
    competitor: "Pricing can grow quickly as users add devices, staff, or sync features",
  },
  {
    feature: "Mobile-first experience",
    dugam: "Fast, responsive, and built for shop floor usage",
    competitor: "Many desktop-first tools need extra steps on mobile",
  },
  {
    feature: "Shop and godown workflows",
    dugam: "Inventory, sales, purchases, and godown tracking in one app",
    competitor: "Often split across modules or add-ons",
  },
]

const competitorFaqs: ProgrammaticFaq[] = [
  {
    question: "Can Dugam replace my current billing or inventory app?",
    answer: "Yes. Dugam is designed as a practical alternative for shops that want a simpler, more affordable billing and stock workflow.",
  },
  {
    question: "Does Dugam support mobile and desktop use?",
    answer: "Yes. The app is built to stay responsive on both desktop browsers and mobile devices so shop teams can work anywhere.",
  },
  {
    question: "Is there a cheaper way to manage inventory and GST billing?",
    answer: "Dugam focuses on a low-entry pricing model with monthly and yearly options that fit small and medium Indian businesses.",
  },
]

const industryFaqs: ProgrammaticFaq[] = [
  {
    question: "Can this app work for my shop type?",
    answer: "Yes. Dugam is built for kirana, hardware, electronics, mobile, wholesale, and godown-centric workflows.",
  },
  {
    question: "Can I print GST invoices and receipts?",
    answer: "Yes. The app supports billing, printable receipts, and business record workflows from the same dashboard.",
  },
  {
    question: "Will this help with stock tracking?",
    answer: "Yes. Stock movement, low-stock signals, purchase records, and reporting are part of the core flow.",
  },
]

const competitorRelatedLinks: ProgrammaticLink[] = [
  { label: "View pricing", href: "/pricing" },
  { label: "Read FAQ", href: "/faq" },
  { label: "Kirana store billing software", href: "/industries/kirana-store" },
  { label: "Wholesale inventory software", href: "/industries/wholesalers-and-godown" },
  { label: "Get support", href: "/support" },
]

const industryRelatedLinks: ProgrammaticLink[] = [
  { label: "View pricing", href: "/pricing" },
  { label: "Read FAQ", href: "/faq" },
  { label: "Vyapar alternative", href: "/alternatives/vyapar" },
  { label: "Hardware shop software", href: "/industries/hardware-shop" },
  { label: "Get support", href: "/support" },
]

// Define categories to dynamically inject based on the page's context or to map over
const businessCategories = {
  retail: ["Kirana stores", "Grocery shops", "General stores", "Provision stores", "Mini marts", "Retail counters"],
  hardware: ["Hardware shops", "Paint shops", "Plumbing shops", "Pipe & fitting shops", "Sanitary shops", "Tiles & cement stores"],
  electronics: ["Electrical shops", "Electronics shops", "Mobile accessory shops", "Battery & inverter shops", "Automobile spare parts"],
  wholesale: ["Wholesalers", "Distributors", "Stockists", "Showrooms", "Storekeepers", "Warehouse teams"]
} as const;

const competitorComparisonPagesBase = [
  {
    slug: "kirana-store-software",
    competitorName: "Kirana Stores",
    title: "Kirana Store Billing & Inventory Management Software | Dugam",
    description:
      "Manage kirana store inventory, GST billing, purchases, sales, customer accounts, and stock tracking from mobile and desktop with Dugam.",
  },
  {
    slug: "grocery-shop-software",
    competitorName: "Grocery Shops",
    title: "Grocery Shop Billing & Inventory Software | Dugam",
    description:
      "Track grocery stock, GST invoices, purchases, sales, and inventory movement with software built for grocery shop owners.",
  },
  {
    slug: "general-store-software",
    competitorName: "General Stores",
    title: "General Store Inventory & GST Billing Software | Dugam",
    description:
      "Simplify inventory management, GST billing, stock tracking, and daily store operations with software designed for general stores.",
  },
  {
    slug: "provision-store-software",
    competitorName: "Provision Stores",
    title: "Provision Store Billing & Inventory Software | Dugam",
    description:
      "Manage provision store stock, GST invoices, purchases, suppliers, and sales records in one easy inventory system.",
  },
  {
    slug: "mini-mart-billing-software",
    competitorName: "Mini Marts",
    title: "Mini Mart Billing & Inventory Management Software | Dugam",
    description:
      "Inventory and billing software for mini marts with stock control, GST billing, sales tracking, and business reports.",
  },
  {
    slug: "hardware-shop-software",
    competitorName: "Hardware Shops",
    title: "Hardware Shop Management Software | Inventory & Billing",
    description:
      "Track hardware inventory, supplier purchases, GST billing, sales records, and stock levels with hardware shop software.",
  },
  {
    slug: "paint-shop-software",
    competitorName: "Paint Shops",
    title: "Paint Shop Billing & Inventory Management Software | Dugam",
    description:
      "Manage paint inventory, product variants, GST billing, stock tracking, and supplier purchases efficiently.",
  },
  {
    slug: "plumbing-shop-software",
    competitorName: "Plumbing Shops",
    title: "Plumbing Shop Inventory & Billing Software | Dugam",
    description:
      "Track plumbing products, inventory levels, GST invoices, purchases, and sales from a single platform.",
  },
  {
    slug: "pipe-and-fitting-shop-software",
    competitorName: "Pipe and Fitting Shops",
    title: "Pipe & Fitting Shop Inventory Software | Dugam",
    description:
      "Manage pipes, fittings, stock movement, GST billing, purchases, and sales with inventory software for pipe stores.",
  },
  {
    slug: "sanitary-shop-software",
    competitorName: "Sanitary Shops",
    title: "Sanitary Shop Billing & Inventory Software | Dugam",
    description:
      "Inventory management software for sanitary shops with GST billing, stock tracking, supplier management, and reporting.",
  },
  {
    slug: "building-material-store-software",
    competitorName: "Tiles, Cement, Iron and Steel Stores",
    title: "Building Material Inventory Management Software | Dugam",
    description:
      "Manage tiles, cement, iron, steel inventory, GST billing, purchases, and stock movement with one powerful solution.",
  },
  {
    slug: "electrical-shop-software",
    competitorName: "Electrical Shops",
    title: "Electrical Shop Billing & Stock Management Software | Dugam",
    description:
      "Track electrical inventory, GST invoices, purchases, suppliers, and sales using software built for electrical stores.",
  },
  {
    slug: "electronics-shop-software",
    competitorName: "Electronics Shops",
    title: "Electronics Store Inventory & Billing Software | Dugam",
    description:
      "Manage electronics inventory, billing, warranty records, stock movement, and customer transactions efficiently.",
  },
  {
    slug: "mobile-accessory-shop-software",
    competitorName: "Mobile Accessory Shops",
    title: "Mobile Accessory Shop Billing Software | Dugam",
    description:
      "Track mobile accessories inventory, GST billing, stock levels, purchases, and sales with ease.",
  },
  {
    slug: "battery-inverter-shop-software",
    competitorName: "Battery and Inverter Shops",
    title: "Battery & Inverter Shop Inventory Software | Dugam",
    description:
      "Manage battery inventory, inverter stock, warranty records, GST invoices, and customer sales from one dashboard.",
  },
  {
    slug: "auto-spare-parts-software",
    competitorName: "Automobile Spare Parts Shops",
    title: "Auto Spare Parts Inventory Management Software | Dugam",
    description:
      "Track spare parts inventory, purchases, suppliers, GST billing, and sales records for automobile businesses.",
  },
  {
    slug: "tyre-tools-store-software",
    competitorName: "Tyre and Tools Stores",
    title: "Tyre & Tools Inventory Management Software | Dugam",
    description:
      "Manage tyre inventory, tool stock, GST billing, supplier purchases, and sales operations efficiently.",
  },
  {
    slug: "wholesale-inventory-software",
    competitorName: "Wholesalers",
    title: "Wholesale Inventory Management Software | GST Billing",
    description:
      "Inventory software for wholesalers with bulk stock tracking, GST billing, purchase management, and sales reporting.",
  },
  {
    slug: "distributor-management-software",
    competitorName: "Distributors",
    title: "Distributor Management Software | Inventory & Billing",
    description:
      "Manage inventory, distributor operations, orders, GST invoices, stock movement, and customer records.",
  },
  {
    slug: "stockist-management-software",
    competitorName: "Stockists",
    title: "Stockist Inventory Management Software | Dugam",
    description:
      "Track warehouse stock, inventory transfers, purchases, GST billing, and supplier management with ease.",
  },
  {
    slug: "showroom-management-software",
    competitorName: "Showrooms",
    title: "Showroom Inventory & Billing Software | Dugam",
    description:
      "Inventory management software for showrooms with stock tracking, GST billing, customer management, and reporting.",
  },
  {
    slug: "store-inventory-software",
    competitorName: "Storekeepers",
    title: "Store Inventory Management Software | Dugam",
    description:
      "Help storekeepers manage inventory, stock records, purchases, sales, GST invoices, and daily operations efficiently.",
  },
  {
    slug: "warehouse-management-software",
    competitorName: "Warehouse and Godown Teams",
    title: "Warehouse Management Software | Inventory Tracking",
    description:
      "Track warehouse inventory, inward and outward stock movement, inventory reports, and warehouse operations in real time.",
  },
] as const;


export const competitorComparisonPages: CompetitorComparisonPageConfig[] = competitorComparisonPagesBase.map((item) => ({
  kind: "competitor",
  ...item,
  h1: "Best Premium Billing App for Indian Shops",
  intro:
    "Dugam is built for Indian MSMEs that want a simpler, mobile-friendly inventory and GST billing workflow with pricing that stays easy to understand.",
  comparisonHeadline: `How Dugam compares with ${item.competitorName}`,
  comparisonNote:
    "The comparison below focuses on publicly visible product positioning and typical market expectations for shop software. Exact vendor features and tiers can change over time.",
  comparisonRows: competitorComparisonRows,
  highlights: [
    "Fast stock and billing workflow",
    "Mobile + desktop friendly",
    "Affordable monthly and yearly plans",
    "Built for kirana, wholesale, and godown teams",
  ],
  faqs: competitorFaqs,
  relatedLinks: competitorRelatedLinks,
}))

export const industryPages: IndustryPageConfig[] = [
  {
    kind: "industry",
    slug: "kirana-store",
    industryName: "Kirana Store",
    title: "Kirana Store Billing Software for Fast Billing and Stock Tracking | Dugam",
    description:
      "Use Dugam as a kirana dukan stock manager app with fast billing, WhatsApp receipt sharing, and simple inventory tracking.",
    h1: "Kirana Store Billing Software for Faster Billing",
    intro:
      "Built for kirana shops that need quick counter billing, simple stock movement, and easy receipt sharing from mobile or desktop.",
    highlights: [
      "Fast billing at the counter",
      "WhatsApp receipt sharing",
      "Low-stock alerts for fast-moving items",
      "Simple daily stock updates",
    ],
    useCases: [
      "Counter billing for daily walk-in customers",
      "Quick stock checks for fast-moving grocery items",
      "Receipt sharing and GST invoice workflows",
    ],
    faqs: industryFaqs,
    relatedLinks: [
      { label: "View pricing", href: "/pricing" },
      { label: "Vyapar alternative", href: "/alternatives/vyapar" },
      { label: "Hardware shop billing software", href: "/industries/hardware-shop" },
      { label: "Support", href: "/support" },
    ],
  },
  {
    kind: "industry",
    slug: "hardware-shop",
    industryName: "Hardware Shop",
    title: "Hardware Store Billing Software and Inventory Management | Dugam",
    description:
      "Track hardware items, purchase records, and GST billing with Dugam for hardware and building-material stores.",
    h1: "Hardware Store Billing Software for Inventory Control",
    intro:
      "Ideal for hardware shops that need purchase tracking, stock visibility, and billing that works across desktop and mobile devices.",
    highlights: [
      "Purchase and supplier records",
      "Stock tracking for bolts, tools, and fittings",
      "GST billing for retail and trade invoices",
      "Responsive mobile and desktop experience",
    ],
    useCases: [
      "Track mixed-item hardware inventory",
      "Manage supplier purchases and bill details",
      "Create customer invoices quickly",
    ],
    faqs: industryFaqs,
    relatedLinks: [
      { label: "View pricing", href: "/pricing" },
      { label: "Busy alternative", href: "/alternatives/busy" },
      { label: "Kirana store billing software", href: "/industries/kirana-store" },
      { label: "Support", href: "/support" },
    ],
  },
  {
    kind: "industry",
    slug: "electronics-and-mobile",
    industryName: "Electronics and Mobile Shop",
    title: "Electronics and Mobile Shop Inventory Software | Dugam",
    description:
      "Manage electronics and mobile stock, billing, and GST invoices with a streamlined app for showroom and counter teams.",
    h1: "Electronics and Mobile Shop Inventory Software",
    intro:
      "Dugam helps electronics and mobile shops handle device stock, accessory billing, and daily sales in a clean workflow.",
    highlights: [
      "Accessory and device stock tracking",
      "Counter billing for walk-in customers",
      "GST invoice generation",
      "Easy product search and quick sale actions",
    ],
    useCases: [
      "Track high-value device stock",
      "Manage accessories and add-on items",
      "Keep invoices ready for customer support and warranty use",
    ],
    faqs: industryFaqs,
    relatedLinks: [
      { label: "View pricing", href: "/pricing" },
      { label: "Swipe alternative", href: "/alternatives/swipe" },
      { label: "Kirana store billing software", href: "/industries/kirana-store" },
      { label: "Support", href: "/support" },
    ],
  },
  {
    kind: "industry",
    slug: "wholesalers-and-godown",
    industryName: "Wholesalers and Godown",
    title: "Wholesale Inventory Management Software for Godown Teams | Dugam",
    description:
      "Control large stock movement, purchase records, and GST billing with a wholesale and godown-ready inventory platform.",
    h1: "Wholesale Inventory Management Software for Godown Teams",
    intro:
      "Designed for wholesalers and godown teams that need low-stock visibility, purchase history, and cleaner stock control.",
    highlights: [
      "Bulk purchase records",
      "Godown-oriented stock tracking",
      "Low-stock alerts and movement visibility",
      "Reporting for stock-heavy businesses",
    ],
    useCases: [
      "Record incoming bulk stock and purchases",
      "Track inventory across godown workflows",
      "Review sales and movement patterns",
    ],
    faqs: industryFaqs,
    relatedLinks: [
      { label: "View pricing", href: "/pricing" },
      { label: "Vyapar alternative", href: "/alternatives/vyapar" },
      { label: "Electronics and mobile shop software", href: "/industries/electronics-and-mobile" },
      { label: "Support", href: "/support" },
    ],
  },
  {
    kind: "industry",
    slug: "clothing-garments",
    industryName: "Clothing and Garments",
    title: "Clothing and Garments Billing Software for Fashion Shops | Dugam",
    description:
      "Manage apparel inventory, size variants, stock movement, and GST billing for clothing and garments businesses with Dugam.",
    h1: "Clothing and Garments Billing Software for Fashion Shops",
    intro:
      "Built for clothing stores and garment businesses that need variant-aware inventory tracking, quick billing, and clean reporting.",
    highlights: [
      "Track sizes, colors, and variants",
      "Fast billing for walk-in fashion customers",
      "Stock visibility for seasonal inventory",
      "Simple reporting for garments and apparel teams",
    ],
    useCases: [
      "Manage apparel stock by size and variant",
      "Create fast invoices for fashion retail counters",
      "Track seasonal sales and inventory movement",
    ],
    faqs: industryFaqs,
    relatedLinks: [
      { label: "View pricing", href: "/pricing" },
      { label: "Vyapar alternative", href: "/alternatives/vyapar" },
      { label: "Wholesale inventory software", href: "/industries/wholesalers-and-godown" },
      { label: "Support", href: "/support" },
    ],
  },
]

export const programmaticPagePaths = [
  ...competitorComparisonPages.map((page) => `/alternatives/${page.slug}`),
  ...industryPages.map((page) => `/industries/${page.slug}`),
] as const

export function getCompetitorComparisonPage(slug: string) {
  return competitorComparisonPages.find((page) => page.slug === slug)
}

export function getIndustryPage(slug: string) {
  return industryPages.find((page) => page.slug === slug)
}
