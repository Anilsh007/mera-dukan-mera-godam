# MDMG Menu and Feature Duplication Audit

## What was checked
- Sidebar route list and visible navigation families.
- Feature families that were looking duplicated from a user point of view.
- Existing free-MVP scope: inventory, purchases, sales, POS, GST, reports, accounting, parties, profile, share/print/export, backup/restore, and subscription placeholder pages.

## What was changed
- The sidebar is now grouped by feature families instead of showing every related page as a flat menu item.
- Navigation data was moved into `app/components/layout/sidebarNav.ts` so future menu changes are not hardcoded inside the Sidebar rendering component.
- `Sidebar.tsx` now has smaller reusable render pieces for parent groups, normal links, and child links.
- Active child routes now automatically keep their parent menu visually active/open.

## New sidebar structure
- Overview
- Sales & Billing
  - Quick Sale
  - POS Billing
  - Sales
  - Estimates
  - Returns & Notes
- Purchase & Stock In
  - Quick Purchase
  - Purchases
  - Recent Purchases
- Inventory Management
  - All Inventory
  - Advanced Inventory
  - Stock History
  - Expiry Alerts
- People & Parties
  - Parties
  - Customers
  - Suppliers
- Accounting & Money
  - Expenses
  - Cashbook
  - Profit & Loss
- GST & Compliance
  - GST Invoice
  - GST Reports
- Reports
- Settings
  - Download Data
  - Backup & Restore
  - Account Settings
  - Billing and Subscription

## Feature duplication decision
- I did not remove routes like Quick Sale/POS/Sales or Parties/Customers/Suppliers because they can serve different user workflows.
- Instead, related routes are grouped so users do not feel the app has repeated features scattered everywhere.
- Removing/merging pages should only happen after real usage testing, because aggressive merging can break existing workflows.

## Free-MVP status
Current project coverage looks strong for a free Indian shopkeeper MVP: inventory, stock movements, purchases, sales/POS, GST invoices, parties, suppliers/customers, reports, print/share/export, backup/restore, profile, and basic subscription gating are present.

Not marked as fully complete until manual QA confirms:
- every grouped menu route opens on mobile/tablet/desktop,
- every important action shows toast feedback,
- sale/purchase/return/estimate stock and totals remain correct,
- GST reports and invoice totals match expected values,
- print/share/download output is correct,
- user-facing text remains centralized.

## Suggested next phase
Run a user-flow audit, not just a code audit: create product, purchase stock, sell via Quick Sale and POS, generate GST invoice, record payment/expense, print/share, export report, backup/restore, and verify stock/history/totals after each step.

## Follow-up fix added in this reviewed patch
- Sidebar dropdown open state now uses stable `id` keys instead of translated labels.
- Active child routes open their parent menu on route change, but the user can still toggle that dropdown normally.
- Clicking a grouped menu while the desktop sidebar is collapsed now expands the sidebar and opens that group, instead of doing nothing.
- Collapsed icon-only links and grouped menu buttons now keep accessible labels for screen readers.

## Checks run on this patch bundle
- Inspected uploaded ZIP contents.
- Verified the patch bundle does not include `package.json` or `tsconfig.json`, so full `npm run lint`, `npm run typecheck`, and `npm run build` cannot be run inside this isolated patch folder.
- Ran targeted grep checks to confirm old sidebar active-label logic was removed from the patched files.

## Phase 1 follow-up: sidebar dropdown, route navigation, and menu usability cleanup

### Sidebar fixes added
- Moved dashboard href values into `app/lib/navigation/dashboardRoutes.ts` so route strings are centralized and reusable outside the sidebar.
- Kept visible sidebar grouping in `app/components/layout/sidebarNav.ts`, with stable parent and child ids.
- Updated `Sidebar.tsx` so dropdown open state is initialized from the active route and then preserved unless the user toggles a group or the route changes.
- Active child routes continue to mark the parent group active.
- Desktop collapsed mode now shows browser titles for icon-only links and expands before opening a group.
- Mobile drawer now closes on normal navigation and also supports Escape-key close.
- Added `aria-controls`, `aria-expanded`, `aria-current`, and accessible labels for grouped controls and links.

### Usability labels simplified
- Replaced confusing sidebar labels with clearer shopkeeper-friendly labels through `app/messages/en.ts`:
  - Sales → Sale Records
  - Purchases → Purchase Records
  - Recent Purchases → Recent Stock In
  - All Inventory → Products & Stock
  - Advanced Inventory → More Stock Tools
  - Parties → All Parties
  - Download Data → Download & Export
  - Billing and Subscription → Plan & Billing

### Navigation improvements added
- `app/dashboard/recent-purchases/page.tsx` now uses centralized labels from `en.ts` instead of hardcoded visible text.
- Recent Stock In now has clear navigation actions for Back to Dashboard and Quick Purchase.
- `app/dashboard/parties/[partyId]/party-detail-client.tsx` now gives a Back to Parties action when a party record is not found, avoiding a dead-end screen.

### Route audit performed on this uploaded patch bundle
The uploaded ZIP is a partial patch bundle, not the full runnable project. These sidebar hrefs had matching `page.tsx` files inside the uploaded bundle:
- `/dashboard/quick-sale`
- `/dashboard/pos`
- `/dashboard/sales`
- `/dashboard/estimates`
- `/dashboard/returns`
- `/dashboard/purchases`
- `/dashboard/recent-purchases`
- `/dashboard/expiry-alerts`
- `/dashboard/expenses`
- `/dashboard/cashbook`
- `/dashboard/profit-loss`
- `/dashboard/gst-reports`

These hrefs did not have `page.tsx` files inside this partial ZIP, but they may already exist in the full project because this bundle contains component/service patches only for many areas. I did not create placeholders for them in this patch because that could overwrite real working pages in the full repo:
- `/dashboard`
- `/dashboard/quick-purchase`
- `/dashboard/all-inventory`
- `/dashboard/advanced-inventory`
- `/dashboard/stock-history`
- `/dashboard/parties`
- `/dashboard/customers`
- `/dashboard/suppliers`
- `/dashboard/gst-invoice`
- `/dashboard/reports`
- `/dashboard/settings/download`
- `/dashboard/backup-restore`
- `/dashboard/settings/account`
- `/dashboard/settings/subscription`

### Commands attempted
- `npm run typecheck` failed because this uploaded patch folder does not include `package.json`.
- `npm run lint` failed because this uploaded patch folder does not include `package.json`.
- `npm run build` failed because this uploaded patch folder does not include `package.json`.

Run these again after applying the patch inside the real project root.

## Phase 2 follow-up: overview dashboard charts and interactive data visualization

### Reusable chart foundation added
- Added `app/components/charts/ChartCard.tsx` as the common chart container with title, description, actions, loading, error, and empty state handling.
- Added `app/components/charts/ChartEmptyState.tsx` for reusable chart empty states and navigation actions.
- Added `app/components/charts/MetricLineAreaChart.tsx` for responsive line/area charts with visible points, keyboard-focusable nodes, and detailed SVG tooltips.
- Added `app/components/charts/MetricBarChart.tsx` for responsive product/stock bar charts with hover/focus tooltips.
- Added `app/components/ui/SvgChartTooltip.tsx` because existing overview chart code referenced this shared tooltip but it was not present in the uploaded patch bundle.

### Dashboard overview data utility added
- Added `app/lib/dashboard/overviewChartData.ts` to build chart-ready data from existing business records without fake/random production data.
- The utility aggregates daily sales, purchases, GST collected/paid, simple profit/loss, due amounts, stock value, stock risk, top products, and slow products from existing records where available.
- The utility is defensive around older/local record shapes and uses typed `Record<string, unknown>` helpers instead of `any`.

### Existing chart components consolidated
- Updated `app/dashboard/components/OverviewMiniTrendChart.tsx` to use the shared line chart and empty state instead of duplicating SVG path/node logic.
- Updated `app/dashboard/components/SalesSparkline.tsx` to use `ChartCard` and `MetricLineAreaChart`, while keeping its existing public props compatible.
- Updated `app/dashboard/components/DashboardStockHealthChart.tsx` to use the common chart shell, actions, loading, and empty-state behavior.
- Updated `app/dashboard/reports/components/LineChart.tsx` to reuse the shared interactive line chart with hover/focus tooltips.

### Dedicated overview chart component added
- Added `app/dashboard/components/DashboardOverviewCharts.tsx` as a ready-to-use overview visualization grid.
- It supports dedicated charts for:
  - Sales trend
  - Purchase trend
  - Stock value trend
  - GST collected/paid trend
  - Profit/loss trend
  - Stock risk trend
  - Due amount trend
  - Top selling products
  - Slow moving products
- Each chart has useful hover/focus tooltip rows and relevant navigation actions such as View sales, Add purchase, View GST report, Create invoice, View low stock, Go to inventory, View reports, and View cashbook.

### Text/constants updates
- Added dashboard chart labels, action labels, empty-state text, tooltip labels, and aria labels to `app/messages/en.ts`.
- No visible chart text was hardcoded inside chart UI components except values passed from existing data.

### Commands attempted
- `npm run typecheck` failed because this uploaded patch folder does not include `package.json`.
- `npm run lint` failed because this uploaded patch folder does not include `package.json`.
- `npm run build` failed because this uploaded patch folder does not include `package.json`.
- Ran a targeted TypeScript transpile check across all `.ts` and `.tsx` files in this patch bundle; it passed for 88 files.

### Remaining Phase 2 risks
- The uploaded ZIP is still a partial patch bundle and does not include the actual `app/dashboard/page.tsx` overview page, package scripts, or complete data service layer.
- `DashboardOverviewCharts` is ready to plug into the real overview page, but final wiring should happen in the full repo using the current dashboard data hook/service so real data remains the source of truth.
- Full semantic typecheck/build must be run in the real project after applying this patch.

## Phase 3 follow-up: simplify project UI and Sales & Billing flow

### Reusable UI simplification components added
- Added `app/components/ui/GuidedStepCard.tsx` for step-by-step sections with icon, short heading, helper text, and optional actions.
- Added `app/components/ui/PageActionLinks.tsx` for reusable next-action navigation cards between related pages.
- Added `app/components/ui/SimpleEmptyState.tsx` for consistent friendly empty states across forms and search results.
- Added `app/components/ui/QuantityStepper.tsx` for mobile-safe plus/minus quantity editing with accessible labels.
- Added `app/components/ui/TransactionOptions.tsx` to provide the missing reusable transaction option UI used by `TransactionActionPanel`.

### Sales & Billing UI simplified
- Updated `app/dashboard/quick-sale/page.tsx` into a clearer 3-step flow:
  1. Find items
  2. Check sale items
  3. Customer and payment
- Added next-action navigation from Quick Sale to Sales Records, Parties/Customers, GST Invoice, and Reports.
- Replaced duplicate inline quantity input behavior with the shared `QuantityStepper`.
- Added friendlier no-product and empty-cart states.
- Updated the save button label to show a clear saving state.

### POS flow simplified
- Updated `app/dashboard/pos/page.tsx` into clear shop-counter steps:
  1. Find or scan item
  2. Check counter bill
  3. Payment and receipt
- Added next-action navigation from POS to Quick Sale, Sales Records, Inventory, and Reports.
- Replaced duplicated plus/minus quantity controls with `QuantityStepper`.
- Added a common modal confirmation before clearing an unsaved bill.
- Added friendlier empty product/cart states.
- Updated the complete bill button label to show a clear saving state.

### Purchase flow simplified
- Updated `app/dashboard/purchases/page.tsx` to use `PageHeader` and next-action navigation for Quick Purchase, Recent Stock In, Suppliers, and Reports.
- Replaced awkward pending quick purchase copy with clearer purchase-focused text constants.
- Added a simple guidance block at the top of the purchase form.
- Updated `app/dashboard/quick-purchase/QuickPurchaseForm.tsx` with the same simple stock-in guidance and a clear saving button state.

### Shared transaction actions improved
- Updated `app/components/sales/SalePaymentSelects.tsx` to show helper text for payment mode and payment status.
- Added `TransactionOptions.tsx` so print/download/share/GST/copy actions share one professional reusable UI instead of relying on duplicated per-page checkbox layouts.

### Text/constants updates
- Added all new labels, helper text, confirmation copy, empty-state text, and navigation labels to `app/messages/en.ts`.
- No new visible Phase 3 text was hardcoded into components.

### Commands attempted
- `npm run typecheck` failed because this uploaded patch folder does not include `package.json`.
- `npm run lint` failed because this uploaded patch folder does not include `package.json`.
- `npm run build` failed because this uploaded patch folder does not include `package.json`.
- Ran a targeted TypeScript transpile check across all `.ts` and `.tsx` files in this patch bundle; it passed for 93 files.

### Remaining Phase 3 risks
- This ZIP is still a partial patch bundle, not the full runnable project. Full route-level verification, semantic typecheck, lint, and production build must be run in the real repo.
- Some referenced shared components and services such as `Button`, `Input`, `Modal`, `PageHeader`, database hooks, and document/share utilities are expected to exist in the full project but are not present in this partial bundle.
- Broader UI simplification for pages not included in this patch bundle should continue in later phases after opening the complete repo.

## Phase 4 - GST Invoice and Universal Professional PDF System

### Scope completed in this patch bundle
- Added a reusable browser-safe professional PDF generator without adding a heavy dependency.
- Added a common A4-friendly document layout for invoices, receipts, sales bills, purchase bills, party statements, and report summaries.
- Added centralized transaction document utilities for business header, party block, item table, tax summary, payment summary, terms, notes, file naming, PDF download, PDF print, and share text.
- Added a reusable `ShareActions` component so print/download/native share/WhatsApp/email/copy actions use the centralized document flow.
- Added GST invoice copy-mode support for customer invoice, own/business copy, both copies, and draft preview.
- Added a reusable `InvoiceCopySelector` component and wired `useGstInvoiceForm` to generate the selected invoice copy/copies during post-save actions.
- Replaced remaining `.txt` share filenames in cashbook, expenses, GST reports, and profit/loss pages with `.pdf` filenames.
- Updated row/report print export to use the centralized professional transaction document flow.
- Added profile and party/customer warnings in transaction document preview so missing business/customer details are visible before PDF/print/share.
- Replaced a hardcoded GST invoice notes heading with `en.ts` text and made the notes layout mobile-safe.

### Files added
- `app/lib/pdf/professionalPdf.ts`
- `app/lib/transactionDocument.ts`
- `app/lib/share.ts`
- `app/components/ui/ShareActions.tsx`
- `app/dashboard/gst-invoice/lib/invoiceCopy.ts`
- `app/dashboard/gst-invoice/components/InvoiceCopySelector.tsx`

### Files updated
- `app/components/ui/TransactionDocument.tsx`
- `app/dashboard/gst-invoice/useGstInvoiceForm.ts`
- `app/dashboard/gst-invoice/components/NoteSection.tsx`
- `app/dashboard/cashbook/page.tsx`
- `app/dashboard/expenses/page.tsx`
- `app/dashboard/gst-reports/page.tsx`
- `app/dashboard/profit-loss/page.tsx`
- `app/lib/export.utils.ts`
- `app/messages/en.ts`

### Validation run in this uploaded bundle
- `npm run typecheck`: failed because this patch ZIP has no `package.json`.
- `npm run lint`: failed because this patch ZIP has no `package.json`.
- `npm run build`: failed because this patch ZIP has no `package.json`.
- TypeScript transpile syntax check across all `.ts` / `.tsx` files: passed for 99 files.

### Remaining integration note
- The full repo should wire `InvoiceCopySelector` into the actual `app/dashboard/gst-invoice/page.tsx` or form layout if that page is present in the real project. This uploaded patch bundle does not include that page file, so the hook and component are ready but the visible selector may need to be placed in the full repo UI.

## Phase 5 - Universal Centered Modal / Popup System

### Modal audit summary
- Modal-related files present in this patch bundle were reviewed with targeted searches for `Modal`, `dialog`, `aria-modal`, `fixed inset`, and popup-style overlays.
- Most business modals already imported `@/app/components/ui/Modal`, but that shared component was missing from this partial bundle.
- Sidebar mobile drawer overlay is intentionally not a modal and was left unchanged.
- No duplicate raw fullscreen popup implementation was found in the included files outside the sidebar drawer; the included sales, POS, inventory, party, supplier, estimate, and return confirmations are now backed by the shared modal component.

### Common modal component added
- Added `app/components/ui/Modal.tsx` as the single reusable centered modal/dialog system.
- The shared modal supports:
  - centered desktop/mobile layout
  - responsive max width sizes: `sm`, `md`, `lg`, `xl`, `full`
  - internal body scrolling for long content
  - accessible `role="dialog"`, `aria-modal`, labelled title, optional description
  - keyboard `Escape` close when allowed
  - focus trap with focus return to the previously focused element
  - body scroll lock while open
  - close button using text from `en.ts`
  - default cancel/primary footer actions
  - form mode via `as="form"`
  - confirmation/warning/detail/form variants
  - disabled close/overlay behavior while saving/loading

### Modals migrated / improved in this bundle
- Existing imports now resolve to the new shared modal system:
  - `app/components/parties/PartyPaymentModal.tsx`
  - `app/dashboard/all-inventory/InventoryLogCorrectionModal.tsx`
  - `app/dashboard/all-inventory/MultiItemSaleModal.tsx`
  - `app/dashboard/all-inventory/StockInModal.tsx`
  - `app/dashboard/all-inventory/StockOutModal.tsx`
  - `app/dashboard/estimates/page.tsx`
  - `app/dashboard/pos/page.tsx`
  - `app/dashboard/returns/page.tsx`
  - `app/dashboard/sales/page.tsx`
  - `app/dashboard/suppliers/SupplierPaymentModal.tsx`
- POS clear-bill confirmation now uses warning styling and a clearer `Keep editing` secondary action.
- Sales cancellation confirmation now uses warning styling and a clearer `Keep editing` secondary action.
- Return confirmation now uses confirmation/warning modal styling based on stock impact and a clearer secondary action.
- Estimate conversion confirmation now uses `Keep editing` for the secondary action.
- Party and supplier payment modals now prevent outside-click close while saving.
- Supplier payment modal footer was simplified to use the shared modal default footer instead of duplicating cancel/save buttons.

### Text/constants
- All new modal-visible labels use existing `en.ts` values such as `en.modals.close`, `en.common.cancel`, `en.common.keepEditing`, and `en.common.processing`.
- No new hardcoded user-facing modal labels were added.

### Validation run in this uploaded bundle
- `npm run typecheck`: failed because this patch ZIP has no `package.json`.
- `npm run lint`: failed because this patch ZIP has no `package.json`.
- `npm run build`: failed because this patch ZIP has no `package.json`.
- TypeScript transpile syntax check across all `.ts` / `.tsx` files: passed for 100 files.

### Remaining Phase 5 risks
- This uploaded bundle is still a partial patch, not the full runnable repository. Final semantic TypeScript validation, lint, and production build must be run after applying the patch inside the real project.
- Additional modals that exist only in the full repo but not in this patch bundle should be migrated to `app/components/ui/Modal.tsx` in a follow-up pass.

## Phase 6 - Supabase schema relationships and idempotent SQL migration

### Audit notes
- The patch bundle still does not include the full runnable repo, `package.json`, `app/lib/db.ts`, `profileSupabase.service.ts`, `supabaseDownload.service.ts`, or concrete Supabase client/table calls.
- Available files show a local-first architecture using Dexie-style hooks/services plus Firebase user identity (`requireUserIdentityFromAuthUser`).
- Local/Dexie collection names found in text/export code include `profiles`, `products`, `productLogs`, `invoices`, `purchases`, `sales`, `estimates`, `returnDocuments`, `expenses`, `cashbookEntries`, `parties`, `partyLedger`, inventory locations/batches/transfers, and backup metadata.
- Because the cloud service files are not present in this ZIP, Phase 6 does not modify runtime sync services. The migration is additive and keeps `user_id` as `text` to remain compatible with Firebase UID/local-first sync.

### Added
- `supabase/migrations/20260521_idempotent_relationships.sql`
  - Idempotent table/column/index creation.
  - Guarded foreign key creation that skips FK creation with a `NOTICE` if orphan historical rows exist.
  - `updated_at` trigger function and per-table triggers.
  - RLS owner policies using `user_id = auth.uid()::text` or trusted `service_role`.
  - Read-oriented compatibility views for `stock_history` and `invoices`, created only when those relation names are unused.
- `supabase/README_MDMG_SCHEMA.md`
  - Supabase SQL Editor and CLI run instructions.
  - Safety/RLS notes for the Firebase/local-first architecture.
- `app/lib/supabase/database.types.ts`
  - TypeScript database table row/insert/update types for the added schema.

### Relationships covered
- business profile to profile.
- products to product categories.
- stock/inventory transactions to products and parties.
- customers/suppliers to unified parties.
- party ledger to parties.
- sales to customers/parties, sale items to sales/products.
- purchases to suppliers/parties, purchase items to purchases/products.
- GST invoices to sales/customers/parties/business profile, invoice items to invoices/products.
- payments to parties/customers/suppliers/sales/purchases/GST invoices.
- expenses/cashbook/sync metadata scoped by `user_id`.

### Validation
- `npm run typecheck`, `npm run lint`, and `npm run build` could not run because this uploaded ZIP is a patch bundle without `package.json`.
- TypeScript transpile syntax check passed across all TS/TSX files in the bundle.
- SQL was reviewed for idempotent patterns, but `psql`/Supabase CLI are not available in this container, so database execution must be tested in Supabase SQL Editor or CLI.

### Remaining risk
- Enabling RLS can block browser Supabase writes if the app currently writes with only Firebase auth and no Supabase Auth/custom JWT. Use the service-role/server sync path or Supabase-compatible JWT before production rollout.
- Existing production data with orphan references will intentionally skip those specific FK constraints. Clean orphan data first, then rerun the migration to add the skipped FKs.

## Phase 7 - Deep duplicate code audit and reusable cleanup

### Duplicate patterns found in this uploaded bundle
- Shared UI primitives were imported from many pages but missing from this patch bundle (`SummaryCard`, `StatusBadge`). This made many pages depend on duplicated or unknown implementations in the full repo.
- Sales records had a custom table, custom status pill, and local pagination logic while report components already used a reusable responsive table.
- Currency/date formatting was repeated with `toLocaleString("en-IN")`, manual `Rs` concatenation, and page-local `formatMoney`/`formatCurrency` helpers.
- Search matching was repeated with `filter(Boolean).join(" ").toLowerCase().includes(query)` in sales/party/quick-sale flows.
- Empty-state dashed boxes were repeated instead of using the shared `SimpleEmptyState` where safe.
- Payment status badges were implemented page-locally instead of a shared status badge variant.

### Reusable components/hooks/utilities added or improved
- Added `app/components/ui/SummaryCard.tsx` as the common summary/KPI card used by sales, purchase, parties, accounting, GST, inventory, returns, and POS pages.
- Added `app/components/ui/StatusBadge.tsx` as the common neutral/success/warning/danger/info badge.
- Added `app/components/ui/PaymentStatusBadge.tsx` for shared paid/partial/unpaid/cancelled/draft display.
- Improved `app/components/ui/ResponsiveDataTable.tsx` with exported column types, optional row class, table class, and empty state support.
- Improved `app/components/ui/Table.tsx` to reuse `SimpleEmptyState` and centralized currency formatting.
- Added `app/lib/search.utils.ts` with `matchesSearchQuery`, `normalizeSearchQuery`, and `buildSearchText`.
- Added `app/hooks/usePagination.ts` to centralize page/page-size/next/previous logic.
- Expanded `app/lib/formatters.ts` with reusable number, currency, Indian date/time, and input-date helpers.

### Files refactored to use shared logic
- `app/dashboard/sales/page.tsx`
  - Replaced custom desktop table with `ResponsiveDataTable`.
  - Replaced local sale status pill with `PaymentStatusBadge`.
  - Replaced local pagination calculations with `usePagination`.
  - Replaced repeated search matching with `matchesSearchQuery`.
  - Replaced manual currency rendering with `formatCurrency`.
- `app/dashboard/parties/PartiesPageContent.tsx`
  - Reused `matchesSearchQuery`, `formatCurrency`, and `SimpleEmptyState`.
- `app/dashboard/parties/[partyId]/party-detail-client.tsx`
  - Reused `formatCurrency`, `formatIndianDateTime`, `PaymentStatusBadge`, and `SimpleEmptyState`.
- `app/dashboard/quick-sale/page.tsx`
  - Reused `matchesSearchQuery` and `formatCurrency`.
- `app/dashboard/pos/page.tsx`, `app/dashboard/estimates/page.tsx`, `app/dashboard/returns/page.tsx`
  - Removed page-local currency helpers and reused `formatCurrency`/`formatIndianDate`.
- `app/components/parties/PartyPaymentModal.tsx`, `app/dashboard/suppliers/SupplierPaymentModal.tsx`
  - Reused centralized formatting helpers.
- `app/dashboard/all-inventory/StockInModal.tsx`, `StockOutModal.tsx`, `MultiItemSaleModal.tsx`, `InventoryLogCorrectionModal.tsx`, and `stock-history.utils.ts`
  - Reused centralized currency/date formatting.
- `app/lib/transactionDocument.ts`, `app/lib/pdf/professionalPdf.ts`, `app/lib/export.utils.ts`, and `app/lib/accounting/accounting.export.ts`
  - Reused centralized date/currency helpers for document/export/share output.

### What was deliberately not consolidated yet
- Business-specific document builders were left separate because sale, purchase, return, estimate, GST invoice, and statement documents have different data semantics even though they now share the common PDF/document layout.
- Estimate status styling was left feature-specific because estimate statuses (`draft`, `sent`, `accepted`, `expired`, etc.) are not the same as payment statuses.
- Full project-wide table/form consolidation cannot be completed from this patch bundle alone because several referenced full-repo files are not present here.

### Validation run in this uploaded bundle
- `npm run typecheck`: failed because this patch ZIP has no `package.json`.
- `npm run lint`: failed because this patch ZIP has no `package.json`.
- `npm run build`: failed because this patch ZIP has no `package.json`.
- TypeScript transpile syntax check across all `.ts` / `.tsx` files: passed for 106 files.

### Remaining Phase 7 risks
- Final semantic TypeScript validation, lint, and production build must be run after applying the patch inside the real project.
- Some additional duplicate code may exist only in the full repository outside this patch bundle and should be audited after applying this patch.

## Final cross-check audit after Phase 1-7

### Overall result in this uploaded patch bundle
- Status: partial pass. The bundle is still a patch subset and does not include `package.json`, `tsconfig.json`, several real dashboard `page.tsx` files, or the full Dexie/Supabase service layer.
- No env/secrets files were modified.
- No destructive data or SQL changes were added.

### Issues found and fixed in final audit
- Some navigation actions still used hardcoded `/dashboard/...` strings instead of the centralized dashboard route config.
  - Fixed by adding `DASHBOARD_ROUTES.profile` and replacing direct GST invoice/profile/parties/inventory navigation in available files.
- Some export error labels were still hardcoded in accounting/GST report pages.
  - Fixed by adding `en.accounting.cashbookExportFailed`, `en.accounting.expenseExportFailed`, `en.accounting.profitLossExportFailed`, and `en.gstReports.exportFailed`.
- Expiry alerts had a hardcoded visible `Expiry` tile label.
  - Fixed to use `en.expiry.expiryPrefix`.
- Overview chart data extraction missed common Supabase/PostgreSQL snake_case fields.
  - Fixed by expanding date, amount, GST, due, stock, rate, and product-name field readers.
- GST overview chart displayed net GST while the chart value label said GST collected.
  - Fixed by adding `en.dashboard.netGst`, using it as the chart value label, and keeping collected/paid details in the tooltip.
- GST chart empty-state detection could hide useful GST data when collected and paid were equal.
  - Fixed by also checking tooltip monetary rows.
- Supabase compatibility views could bypass row-level security depending on Postgres view behavior.
  - Fixed by creating `stock_history` and `invoices` views with `security_invoker = true`.

### Route audit result from the patch bundle
- Route config and sidebar are centralized through `app/lib/navigation/dashboardRoutes.ts` and `app/components/layout/sidebarNav.ts`.
- Routes present in this patch subset include quick sale, POS, sales, estimates, returns, purchases, recent purchases, expiry alerts, expenses, cashbook, profit/loss, and GST reports.
- Several sidebar routes cannot be verified in this patch subset because their real `page.tsx` files are not included here: dashboard overview, quick purchase page wrapper, all inventory page wrapper, advanced inventory, stock history, parties, customers, suppliers, GST invoice page wrapper, reports, download/settings, backup/restore, account settings, subscription settings, and profile page wrapper.
- Placeholder pages were not created during final audit because doing so in a patch ZIP could overwrite working real pages when applied to the full repo.

### Validation run in final audit
- `npm run typecheck`: failed because this patch ZIP has no `package.json`.
- `npm run lint`: failed because this patch ZIP has no `package.json`.
- `npm run build`: failed because this patch ZIP has no `package.json`.
- TypeScript transpile syntax check across all `.ts` / `.tsx` files: passed for 106 files.
- Direct dashboard string scan after fixes: no direct `router.push("/dashboard...`)` or `href="/dashboard...` matches found in the available files.
- Hardcoded export label scan after fixes: no `errorLabel: "..."` matches found in the available files.
- `.txt` output scan after fixes: only defensive `.txt` to `.pdf` filename conversion remains in PDF/share helpers.

### Manual testing still required in the full repo
- Apply the patch to the real repository and run `npm run typecheck`, `npm run lint`, and `npm run build` from the real project root.
- Open every sidebar link and verify the real routes load.
- Test add/edit/delete product, stock in/out, quick purchase, quick sale, POS sale, multi-item sale, returns, GST invoice creation, party ledger, supplier dues, payments, reports, and backup/restore flows.
- Test print/download/share PDF flows in Chrome mobile, Android WebView/PWA if used, and desktop.
- Test RLS migration on staging before production because the app appears Firebase/Dexie local-first and may need a service-role or Supabase-compatible JWT sync path.

## Build Fix: Share compatibility exports

- Added backward-compatible `buildReportShareMessage` export in `app/lib/share.ts` for existing reports header imports.
- Added backward-compatible `downloadTextFile` export in `app/lib/share.ts` for backup/restore exports that still need text/JSON/CSV-style downloads.
- Kept PDF transaction helpers unchanged and did not modify backup data format.
- Validation: TypeScript transpile syntax check passed across 106 TS/TSX files.
