create table if not exists public.sales (
  id text primary key,
  user_id text not null,
  receipt_no text not null,
  sale_date date not null,
  sale_date_time timestamptz not null,
  customer jsonb,
  items jsonb not null default '[]'::jsonb,
  total_amount numeric(12,2) not null default 0,
  taxable_amount numeric(12,2) not null default 0,
  gst_amount numeric(12,2) not null default 0,
  amount_paid numeric(12,2) not null default 0,
  due_amount numeric(12,2) not null default 0,
  payment_status text not null,
  payment_mode text not null,
  note text,
  reference text,
  gst_enabled boolean not null default false,
  entry_mode text not null,
  status text not null default 'completed',
  cancelled_at timestamptz,
  cancellation_note text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (user_id, receipt_no)
);

create index if not exists sales_user_date_idx on public.sales (user_id, sale_date_time desc);
create index if not exists sales_user_status_idx on public.sales (user_id, payment_status, status);
