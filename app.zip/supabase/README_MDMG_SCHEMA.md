# MDMG Supabase schema migration

Migration file:

- `supabase/migrations/20260521_idempotent_relationships.sql`

## How to run

### Supabase SQL Editor

1. Open your Supabase project.
2. Go to **SQL Editor**.
3. Paste the full SQL from the migration file.
4. Run it once.
5. It is idempotent, so it can be run again if deployment is interrupted.

### Supabase CLI

From the real project root, after copying this patch into the repo:

```bash
supabase db push
```

Or run directly against a linked project using your existing Supabase CLI setup.

## Safety notes

- The migration does not drop tables.
- The migration does not delete rows.
- Existing columns are not recreated destructively.
- Foreign keys are added only when existing data has no orphan rows; otherwise the migration prints a `NOTICE` and skips that specific FK.
- Indexes are non-unique where duplicate historical rows could otherwise make a safe migration fail.
- `user_id` is stored as `text` because the app currently appears to use Firebase/Dexie local-first ids.
- RLS policies expect `user_id = auth.uid()::text` or a trusted `service_role` path.
- Compatibility views use `security_invoker = true` so reads continue to respect underlying table RLS.
- If cloud sync currently writes to Supabase from a Firebase-only browser client without Supabase Auth/custom JWT, test on staging first and route sync through a trusted server/service-role path before production.
