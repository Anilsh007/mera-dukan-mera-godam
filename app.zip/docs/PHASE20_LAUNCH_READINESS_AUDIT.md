# Phase 20 Launch Readiness Audit

Last updated: 2026-05-21

## Scope

Independent final QA and launch-readiness audit after Phases 1-19. This pass cross-checked route compilation, TypeScript, lint, build compilation, core business services, stock/payment/GST safety, private-page indexing, subscription placeholders, scanner support, and data safety flows.

## Readiness Summary

Overall readiness: 92%.

The project is close to launch readiness for a controlled beta/staging rollout. No TypeScript or lint errors remain, and all app routes compile in Next.js compile mode. The main remaining verification blocker is that the sandbox times out during full `next build` page-data collection after successful production compilation, so the full build should be rerun on the target local machine or deployment CI before public launch.

## Issues Found and Fixed

1. Lint warnings existed in shared UI and GST invoice components.
   - Removed unused imports/variables.
   - Restored `ShareActions` prop behavior for print/download/compact/className.
   - Replaced a direct function call of `SellerSection` with a normal React component render.

2. Next.js generated route types could fail after a build.
   - Updated SEO search param typing to match Next.js async `searchParams` expectations.

3. Barcode scanner could be blocked by security headers.
   - Changed Permissions-Policy from `camera=()` to `camera=(self)` so same-origin browser-camera scanning can work after user permission.

4. Sale due records could be saved without a customer name through lower-level service calls.
   - Added service-level due validation to require customer details when amount remains due.

5. Party balances could become stale immediately after sale, purchase, quick-purchase completion, or sale cancellation.
   - Added balance sync after those writes.

6. Sale cancellation restored simple product stock but did not restore advanced godown/location stock.
   - Added advanced inventory stock restoration during sale cancellation.

7. Some service-level user-facing errors were hardcoded.
   - Moved stock, purchase, profile, and sync-facing error messages to `en.ts` or existing text constants.

## Verification Results

- `npm run typecheck`: passed.
- `npm run lint`: passed with 0 errors and 0 warnings.
- `NEXT_PRIVATE_BUILD_WORKER_COUNT=1 npx next build --experimental-build-mode compile`: passed and listed all public, dashboard, API, sitemap, robots, and manifest routes.
- `npm run build`: production compilation and TypeScript stage passed, then sandbox timed out during page-data collection.
- `npx next build --webpack`: production compilation passed, then sandbox timed out during TypeScript/page-data stage.

## Route Coverage Confirmed by Compile Mode

Public routes compile:

- `/`
- `/about`
- `/faq`
- `/login`
- `/pricing`
- `/privacy-policy`
- `/support`
- `/terms`
- `/robots.txt`
- `/sitemap.xml`
- `/manifest.webmanifest`

Dashboard routes compile:

- `/dashboard`
- `/dashboard/all-inventory`
- `/dashboard/advanced-inventory`
- `/dashboard/backup-restore`
- `/dashboard/cashbook`
- `/dashboard/customers`
- `/dashboard/estimates`
- `/dashboard/expenses`
- `/dashboard/expiry-alerts`
- `/dashboard/gst-invoice`
- `/dashboard/gst-reports`
- `/dashboard/parties`
- `/dashboard/parties/[partyId]`
- `/dashboard/pos`
- `/dashboard/profile`
- `/dashboard/profit-loss`
- `/dashboard/purchases`
- `/dashboard/quick-purchase`
- `/dashboard/quick-sale`
- `/dashboard/recent-purchases`
- `/dashboard/reports`
- `/dashboard/returns`
- `/dashboard/sales`
- `/dashboard/settings/account`
- `/dashboard/settings/download`
- `/dashboard/settings/subscription`
- `/dashboard/stock-history`
- `/dashboard/suppliers`

API routes compile:

- `/api/invoices`
- `/api/products/sync`
- `/api/profile`
- `/api/purchases/sync`

## Remaining Launch Blockers

1. Full production build finalization must be verified outside this sandbox because the sandbox times out during page-data collection after successful compilation.
2. Real-device browser testing is still required for camera scanning, print dialogs, native share, and mobile touch behavior.

## Remaining Non-Blocking Improvements

- Extend Supabase sync to newer local Dexie tables from Phases 14-19.
- Add automated unit/integration tests for GST totals, stock movement, party ledger balances, backup/restore, and subscription guards.
- Add full serial/IMEI tracking later; the current implementation is intentionally placeholder-only.
- Add safe hold-bill storage later; the current POS implementation intentionally keeps it disabled.
- Add official GST/e-invoice/e-way bill integration only through proper future API/GSP work.

## Final Recommendation

Ready for staging/beta after one successful full `npm run build` on the target machine or CI. Do not launch publicly until full production build finalization and real-device QA are completed.
