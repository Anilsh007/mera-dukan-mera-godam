# MDMG Phase Status

Last updated: 2026-05-21

## Completed Phases

- Phase 1 to Phase 7: Core inventory, purchase, GST invoice, profile, supplier, stock history, and dashboard foundations were previously completed before this status document was introduced.
- Phase 7.5: Quality gate completed. See `PHASE_7_5_QUALITY_GATE.md`.
- Phase 8: Performance, reports, and export pass completed. See `PHASE_8_PERFORMANCE_REPORT.md`.
- Phase 9: Subscription foundation and plan guard completed with local Dexie persistence, plan utilities, route-level UI, placeholder billing, and guardrails on key create or export actions.
- Phase 10: Quick sale and sales module completed with dedicated sale routes, a reusable sale service, sale records, cancellation flow, and inventory-module sale reuse.
- Phase 11: Customer and party ledger completed with reusable party records, payment received/paid support, legacy purchase and sale mapping, dedicated customer and party routes, and statement/reminder actions.
- Phase 12: POS / Counter Billing completed with `/dashboard/pos`, fast product search, cart billing, quantity plus/minus controls, recent/frequent quick picks, cash received and change-return calculation, UPI mode with optional profile UPI QR, reusable sale service integration, receipt/share/download options, and plan guards.
- Phase 13: Barcode and QR Scanner completed with native browser-camera scanning, manual barcode/SKU fallback, inventory scan-to-find, Quick Sale/POS scan-to-cart, Quick Purchase scan-to-stock-entry assistance, existing SKU/barcode field reuse, graceful unsupported-browser and permission-denied feedback, lazy-loaded scanner UI, and barcode scanner subscription guard.
- Phase 14: Estimate / Quotation completed with `/dashboard/estimates`, local estimate records, customer/party selection, item/quantity/price/discount/GST calculation, profile/default terms, expiry date, draft/sent/accepted/rejected/converted/expired status handling, print/share/download support, GST invoice draft conversion, and conversion to sale through the existing sale service so stock reduces only after conversion.
- Phase 15: Returns, Credit Note, Debit Note, and Delivery Challan completed with `/dashboard/returns`, local correction documents, sale/purchase linking, sale return and credit note stock-in corrections, purchase return and debit note stock-out corrections with negative-stock prevention, delivery challan document-only support, reusable GST calculation, centralized print/share/download documents, audit notes in stock history, and subscription guards.
- Phase 16: Expenses, Cashbook, and Profit & Loss completed with `/dashboard/expenses`, `/dashboard/cashbook`, and `/dashboard/profit-loss`, local accounting records, expense categories, manual cashbook entries, derived cashbook entries from sales/purchases/expenses, daily opening/closing cash summary, profit/loss summaries, monthly comparison, due snapshots, export/print/share actions, and accounting subscription guards.
- Phase 17: Advanced Inventory completed with `/dashboard/advanced-inventory`, batch and expiry tracking extensions, reorder-level support, serial/IMEI placeholder fields, godown/location records, product stock by location, stock transfer workflow with confirmation, transfer history, godown/batch/expiry filters, export/print, and safe compatibility with existing product stock totals.
- Phase 18: Advanced GST Reports and CA Exports completed with `/dashboard/gst-reports`, GST sales register, GST purchase register, HSN summary, B2B summary, B2C summary, GSTR-1 style summary, GSTR-3B style summary, GST collected/paid summary, month/quarter/custom filters, CSV/Excel/print/PDF-safe export, CA review export, subscription export guards, and clear placeholders/disclaimers for e-invoice, e-way bill, and official GST portal/API/GSP integration.
- Phase 19: Backup, Restore, Import, and Export Hardening completed with `/dashboard/backup-restore`, full local JSON backup, module CSV exports, validated restore/import previews, duplicate prevention, confirmation modals, rollback-safe Dexie restore transactions, safe product/customer/supplier imports, export subscription guards, and no silent overwrite or delete behavior.
- Phase 20: Final QA and Launch Readiness completed with an independent route/build/type/lint/business-logic audit, zero lint warnings, scanner security-header fix, Next.js route type fix, due-customer service validation, party balance sync after writes, advanced location-stock restoration on sale cancellation, shared action cleanup, and documented launch readiness in `docs/PHASE20_LAUNCH_READINESS_AUDIT.md`.

## Current Phase

- Phase 20 is the latest completed QA phase.
- Repository is ready for staging/beta verification after one successful full production build on the target machine or CI.

## Pending Phases

- None in the current roadmap. Future work should be planned after staging feedback.

## Last Commands Run

- `rm -rf /mnt/data/mdmg_phase20_work && mkdir -p /mnt/data/mdmg_phase20_work && unzip -q /mnt/data/mdmg_phase19_updated.zip -d /mnt/data/mdmg_phase20_work`
- `sed -n '1,220p' AGENTS.md`
- `sed -n '1,260p' docs/MDMG_PHASE_ROADMAP.md`
- `sed -n '1,320p' docs/PHASE_STATUS.md`
- `cat package.json`
- `npm install --prefer-offline --no-audit --progress=false --ignore-scripts --omit=optional`
- `npm run typecheck`
- `npm run lint`
- `npm install @next/swc-linux-x64-gnu --no-save --prefer-offline --no-audit --progress=false --ignore-scripts`
- `npm run build`
- `NEXT_PRIVATE_BUILD_WORKER_COUNT=1 npx next build --experimental-build-mode compile`
- `npx next build --webpack`

## Remaining Risks

- `npm run typecheck` passes, including after Next.js generated `.next/types` are present.
- `npm run lint` passes with 0 errors and 0 warnings.
- Next.js compile mode passes and lists all public, dashboard, API, sitemap, robots, and manifest routes.
- Full `npm run build` reaches successful production compilation and TypeScript, then this sandbox times out during page-data collection. Verify full build finalization on local hardware or CI before public launch.
- Real-device testing is still required for camera scanner permission, native share, print dialogs, and responsive touch behavior.
- Supabase sync still does not cover every newer local table from Phases 14-19.

## Phase 20 Implementation Notes

- Added `docs/PHASE20_LAUNCH_READINESS_AUDIT.md`.
- Cleaned shared action/GST invoice UI warnings so lint now has zero warnings.
- Restored `ShareActions` print/download/compact/className behavior and accessible action labels.
- Fixed public page `searchParams` typing for Next.js 16 generated route types.
- Changed the security Permissions-Policy to allow same-origin camera access for the Phase 13 scanner.
- Added service-level due validation so sales with due amounts require customer details.
- Synced party balances after sale save, sale cancellation, purchase save, and quick-purchase details completion.
- Restored advanced godown/location stock during sale cancellation.
- Replaced remaining user-facing service error strings in stock, purchase, profile, and sync flows with `en.ts`/existing constants where applicable.

## Next Recommended Phase

- Staging/beta deployment QA, then plan future post-launch improvements based on real user feedback.

## Command 20.5 - Release Candidate Cross-Check

Last updated: 2026-05-21

- Completed independent release-candidate cross-check after Phase 20 without adding new features or starting a new phase.
- Added `docs/RELEASE_READINESS_REPORT.md`.
- Re-ran TypeScript and scoped ESLint checks across routes, components, hooks, lib modules, messages, API routes, SEO routes, proxy, and config.
- Fixed a stock-correction blocker where sales returns, purchase returns, credit notes, and debit notes updated simple inventory totals but did not update advanced godown/location/batch stock rows.
- Hardened safe product/customer/supplier import so duplicates are re-checked immediately before import and committed in a Dexie transaction.
- Moved remaining Firebase/auth and duplicate-product service messages into `en.ts` text constants.
- Hardened ESLint ignores for dependency/generated folders.
- `npm run typecheck` passed.
- Scoped ESLint checks passed with no reported errors or warnings.
- No `test` script exists in `package.json`.
- `next build` compiled successfully in this sandbox, then timed out/terminated during TypeScript or page-data collection; full build finalization still needs local/CI verification.

### Command 20.5 Final Recommendation

- Ready for controlled beta / soft launch after one successful full production build on the deployment machine or CI and real-device smoke testing.
- Not recommended for full public launch until those two verification items are complete.
