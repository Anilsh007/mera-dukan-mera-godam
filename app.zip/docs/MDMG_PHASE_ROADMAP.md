# MDMG Phase Roadmap

This roadmap extends the completed MDMG foundation work and defines the next durable phase sequence for planning, implementation, and verification.

## Completed Foundation Context

- Phases 1 to 7: Core inventory, purchase, profile, GST invoice, supplier, history, and dashboard foundations were already established before this roadmap update.
- Phase 7.5: Quality gate, accessibility, SEO, PWA-safety, and Lighthouse hardening.
- Phase 8: Performance, reports, and export pass.

## Future Phases

### Phase 9: Subscription Foundation and Plan Guard

- Add subscription domain model, plan enums, trial/expired states, usage limits, and plan-guard utilities.
- Enforce read-only/premium create-update restrictions safely without deleting user data.
- Add placeholder payment-provider interfaces only, with no live keys or gateway integration.

### Phase 10: Quick Sale and Sales Module

- Introduce quick sale and more structured sales flows.
- Reuse inventory, receipt, GST, print/share/download, and transaction-history systems.
- Keep logged-in business as seller and party records inside the business.

### Phase 11: Customer and Party Ledger

- Add reusable customer/party records with ledger, due tracking, payment status, and history.
- Support the same party being customer, supplier, or both.
- Keep flows simple for low-technical users.

### Phase 12: POS / Counter Billing

- Build fast counter-sale workflow optimized for keyboard/touch and low-end devices.
- Add hold-bill and quick item-entry improvements where safe.
- Reuse print/share/download and plan-guard logic.

### Phase 13: Barcode and QR Scanner

- Add safe barcode scan flows and barcode-ready item lookup.
- Preserve offline compatibility where possible.
- Avoid heavy scanner dependencies unless required.

### Phase 14: Estimate / Quotation

- Add estimate/quotation flow with conversion-safe reusable transaction structures.
- Keep print/share/download support available where suitable.

### Phase 15: Returns, Credit Note, Debit Note, Delivery Challan

- Add reusable reverse/adjustment document flows.
- Preserve stock history and prevent unsafe corrections.
- Reuse GST/document utilities instead of duplicating business logic.

### Phase 16: Expenses, Cashbook, Profit & Loss

- Add cashbook and expense recording with lightweight reporting.
- Maintain simple UX for shopkeepers and correct business totals.

### Phase 17: Advanced Inventory

- Expand inventory with stronger controls such as godown/location support, advanced stock controls, or richer stock views where architecture allows.
- Preserve responsiveness and low-end device performance.

### Phase 18: Advanced GST Reports and CA Exports

- Improve GST reporting, export formats, and CA-friendly outputs.
- Keep GST logic centralized and do not fake official portal integrations.

### Phase 19: Backup, Restore, Import, Export Hardening

- Harden backup/restore/import/export flows with validation, safety checks, and user-friendly failure handling.
- Protect existing business data and prevent destructive mistakes.

### Phase 20: Final QA and Launch Readiness

- Execute final quality, regression, performance, accessibility, SEO, and launch-readiness checks.
- Confirm plan-guard behavior, premium restrictions, exports, receipts, and core business flows.

## Roadmap Rules

- Build future phases incrementally.
- Reuse existing shared UI, hooks, services, and transaction systems.
- Keep user-facing text inside the localization system.
- Verify each phase with the closest safe lint/typecheck/build checks available in the environment.
